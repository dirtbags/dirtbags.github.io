<?php
include ("rb_include.php");

$GROK_VERSION = "1.3";

$SLICE = $RB_CAP_MINUTES*60;
$LEFTMOST = 56;
$SETEXHIBIT="DecodeIP";
$VLAN = "";

$isin = '&#8712;';
$notin = '&#8713;';
$or = '&#8744;';

$dcodes = array (
        "decodeip", "tcpdump", "bag", "snort", "smacqq",
        "bro", "nosehair", "payload", "pcap", "OS");

$sdcodes = array (
        "decodeip", "tcpdump", "bag", "snort",
        "payload", "pcap", "OS");

$pdcodes = array (
        "decodeip", "tcpdump", "bag", "snort", "smacqq",
        "bro", "nosehair", "pcap");

$suffixs = array ( "decodeip"=>"dip",
		   "tcpdump"=>"td",
		   "pcapfile"=>"pcap",
		   "bag"=>"bag",
		   "snort"=>"snort",
		   "smacqq"=>"smacqq",
        	   "bro"=>"bro",
		   "nosehair"=>"wtf",
		   "payload"=>"pcap",
		   "OS"=>"p0f",
		   "pcap"=>"pcap");

$stat_cols = array ("Freq", "Src", "Dst", "Proto", "Port", "TTL", "Duration",
                    "Src Pkts", "Src Bytes", "Dst Pkts", "Dst Bytes");

$wfcmods = array ("", "anomoaly_cluster", "apphead", "bandwidth", "bistat", "clen",
                  "cluster_gram", "delaybuffer", "dnsgrab", "dnssteal",
		  "fasttrac", "firstbytes", "firstduration", "firstpairport",
		  "firstpkt", "hostconn -A", "hotip", "hotpairs", "idetect", 
		  "iseq", "konnections", "longtermflow", "matchcontent",
		  "matchpkt", "matchsession", "nodeprofile", "nonascii",
		  "pairproto", "pairflowtime", "pairperiod", "periodic",
		  "portclassify", "printaddr", "printflow", "printpkt", 
		  "profilecontent", "protoselect", "runlen", "selectclient",
		  "serverguess", "slice", "startsynflows", "streamstat",
		  "supertirm", "tagger", "tagftp", "tcpexec", "tcphole",
		  "timedelay", "transition", "verifyproto", "webarf2",
		  "webtagger" );

$bromods = array ( "",
"active",
"adu",
"alarm",
"analy",
"anon",
"backdoor",
"blaster",
"brolite",
"brolite-sigs",
"capture-events",
"checkpoint",
"conn-id",
"conn",
"contents",
"cpu-adapt",
"demux",
"dns-info",
"dns-lookup",
"dns",
"drop-adapt",
"file-flush",
"finger",
"firewall",
"flag-irc",
"flag-warez",
"frag",
"ftp-anonymizer",
"ftp-cmd-arg",
"ftp-reply-pattern",
"ftp-safe-words",
"ftp",
"gnutella",
"hand-over",
"hot-ids",
"hot",
"http-abstract",
"http-body",
"http-entity",
"http-event",
"http-header",
"http-reply",
"http-request",
"http-rewriter",
"http",
"icmp",
"ident-rewriter",
"ident",
"inactivity",
"interconn",
"irc",
"large-conns",
"listen-clear",
"listen-ssl",
"load-level",
"login",
"mime",
"mime-pop",
"mt",
"netstats",
"nfs",
"notice",
"ntp",
"OS-fingerprint",
"pcap",
"peer-status",
"pkt-profile",
"pop3",
"port-name",
"portmapper",
"print-filter",
"print-globals",
"print-resources",
"print-sig-states",
"profiling",
"passwords",
"reduce-memory",
"remote-pcap",
"remote-ping",
"remote-print",
"remote",
"rotate-logs",
"rsh",
"scan",
"secondary-filter",
"sensor-sshd",
"ssh",
"signatures",
"site",
"smtp-relay",
"smtp-rewriter",
"smtp",
"snort",
"software",
"ssh-stepping",
"ssl-alerts",
"ssl-ciphers",
"ssl-errors",
"ssl-worm",
"ssl",
"stats",
"stepping",
"synflood",
"tcp",
"tftp",
"trw",
"udp",
"udp-common",
"vlan",
"weird",
"worm",
"sigs/ex.web-rules.sig",
"sigs/p0fsyn.osf",
"sigs/snort-default.sig",
"sigs/ssl-worm.sig",
"sigs/worm.sig",
"bro.bif",
"event.bif",
"const.bif",
"common-rw.bif",
"finger-rw.bif",
"ident-rw.bif",
"ftp-rw.bif",
"smtp-rw.bif",
"http-rw.bif",
"strings.bif" );
$smacqqmods = array ("", "topips");
$view_choices = array ( "decodeip"=>"both",
                  "pcap"=>"both",
                  "tcpdump"=>"both",
                  "snort"=>"both",
                  "bag"=>"both",
                  "payload"=>"sess",
                  "nosehair"=>"pkts",
		  "bro"=>"pkts",
		  "smacqq"=>"pkts");

$curbpf     = "";
$bpf        = "";
$icmp = array (	"0"=>"echoreply",
		"1"=>"una",
		"2"=>"una",
		"3"=>"unreach",
		"4"=>"quench",
		"5"=>"redirect",
		"6"=>"altaddr",
		"7"=>"una",
		"8"=>"echo",
		"9"=>"rtradv",
		"10"=>"rtrsol",
		"11"=>"ttlex",
		"12"=>"parprob",
		"13"=>"time",
		"14"=>"timereply",
		"15"=>"info",
		"16"=>"inforeply",
		"17"=>"mask",
		"18"=>"maskreply",
		"19"=>"res",
		"20"=>"res",
		"21"=>"res",
		"22"=>"res",
		"23"=>"res",
		"24"=>"res",
		"25"=>"res",
		"26"=>"res",
		"27"=>"res",
		"28"=>"res",
		"29"=>"res",
		"30"=>"tracert",
		"31"=>"dce",
		"32"=>"mobilehost",
		"33"=>"ipv6where",
		"34"=>"ipv6here",
		"35"=>"mobilereq",
		"36"=>"mobilerep",
		"37"=>"domainreq",
		"38"=>"domainrep",
		"39"=>"skip",
		"40"=>"photuris",
		"33"=>"seamoby",
		"echoreply"=>"0",
		"una"=>"1",
		"una"=>"2",
		"unreach"=>"3",
		"quench"=>"4",
		"redirect"=>"5",
		"altaddr"=>"6",
		"una"=>"7",
		"echo"=>"8",
		"rtradv"=>"9",
		"rtrsol"=>"10",
		"ttlex"=>"11",
		"parprob"=>"12",
		"time"=>"13",
		"timereply"=>"14",
		"info"=>"15",
		"inforeply"=>"16",
		"mask"=>"17",
		"maskreply"=>"18",
		"tracert"=>"30",
		"dce"=>"31",
		"mobilehost"=>"32",
		"ipv6where"=>"33",
		"ipv6here"=>"34",
		"mobilereq"=>"35",
		"mobilerep"=>"36",
		"domainreq"=>"37",
		"domainrep"=>"38",
		"skip"=>"39",
		"photuris"=>"40",
		"seamoby"=>"33");

$pkt_fields = array(
	      "1"=>"", "2"=>"", "3"=>"proto", "4"=>"src host", "5"=>"dst host",
	      "6"=>"src port", "7"=>"dst port",  "proto"=>"3", "src host"=>"4",
	      "dst host"=>"5", "src port"=>"6", "dst port"=>"7"
              );

$month = array(
	"January"=>1, "February"=>2, "March"=>3, "April"=>4, "May"=>5, "June"=>6,
	"July"=>7, "August"=>8, "September"=>9, "October"=>10, "November"=>11, "December"=>12,
	"Jan"=>1, "Feb"=>2, "Mar"=>3, "Apr"=>4, "May"=>5, "Jun"=>6,
	"Jul"=>7, "Aug"=>8, "Sep"=>9, "Oct"=>10, "Nov"=>11, "Dec"=>12,
	"jan"=>1, "feb"=>2, "mar"=>3, "apr"=>4, "may"=>5, "jun"=>6,
	"jul"=>7, "aug"=>8, "sep"=>9, "oct"=>10, "nov"=>11, "dec"=>12,
	"1"=>1, "2"=>2, "3"=>3, "4"=>4, "5"=>5, "6"=>6,
	"7"=>7, "8"=>8, "9"=>9, "10"=>10, "11"=>11, "12"=>12
	);
// order is important

$session = array(
	"TIME","MINUTES","NPROTO", "PROTO","NSRC","SRC","NDST","DST","NSPT","SPT",
        "NDPT","DPT", "RECORDS", "NSCONTENT","SCONTENT", "NDCONTENT",
        "DCONTENT", "FIELDS","DETAILS", "LENGTH", "NSPKT", "SPKT",
        "NDPKT", "DPKT", "NSBYTES", "SBYTES", "NDBYTES", "DBYTES",
        "NSTTL", "STTL", "NDTTL", "DTTL", "FROMLINK", "TOLINK",
        "SFLAGS", "NSFLAGS", "DFLAGS", "NDFLAGS", "NDURATION", "DURATION",
	"EXHIBIT");

// verify mac org relationships file LINKADDRS (which allows you to change
// these settings depending on your situcation.

$rtr = popen ("cat $RB_ETC_DIR/grok/LINKADDRS | sed -n -e '/^[0-9a-zA-Z]/p'", "r");
$mnemaccnt = 0;
$domainaddr = "";

while (!feof ($rtr))
{
  $tmp = trim (fgets ($rtr, 255));
  $x = strspn($tmp, "abcdefghijklmnopqrstuvwxyz0123456789");
  if ($x > 0)
  {
    $mnemac = split(" ", $tmp, 2);
    $mne = "$mnemac[0]";
    $mac = "$mnemac[1]";
    $len = strlen($mne[0]);
    if ($len > 12) { 
      $sub = substr ($mne, 0, 12);
      die ("mac strlen greater then 12: $sub...\n");
    }
    $len = strlen($mac);
    if ( $len > 4) {
      die ("invalid mac: '$mac' length $len greater than 4 in LINKADDRS!</body></html>\n");
    }
    if (($mnemaccnt > 0) && ($oldmne != $mne)) {
      $domainaddr = "";
    }
    $x = strspn($mac, "0123456789abcdef");
    if ($x < (strlen ($mac)-1)) {
      die ("invalid mac data: $mac, in LINKADDR for $mne\n");
    }
    #if ($DEBUG) {syslog (LOG_DEBUG, "adding $mac to $mne and vise versa");}
    $linkaddrs[$mnemaccnt] = "$mne";
    $linkaddrs[$mne] = "$domainaddr$mac";
    $linkaddrs[$mac] = $mne;
    #print "linkaddrs.mne =  $linkaddrs[$mne], linkaddrs.mac =  $linkaddrs[$mac]<br>";
    if ($mne == $RB_DOMAIN)
    {
      $domainaddr="$linkaddrs[$mne]|";
    }
    $mnemaccnt ++;
    $oldmne = $mne;
  }
}

$state_flags = array(
             "f"=>256,
             "C"=>128, "E"=>64, "U"=>32, "A"=>16,
             "P"=>8, "R"=>4, "S"=>2, "F"=>1
             );

$field_max = count($session);
$CONTENT_HELP = "<a href=\"grok_help.php?file=content_help\" TARGET=\"Packet Content Help\"><img src=\"images/help1.png\"></a>";
$SPKT_HELP = "<a href=\"grok_help.php?file=pktcnt_help\" TARGET=\"Packet Count Help\"><img src=\"images/help1.png\"></a>";
$DPKT_HELP = "<a href=\"grok_help.php?file=pktcnt_help\" TARGET=\"Packet Count Help\"><img src=\"images/help1.png\"></a>";
$STTL_HELP = "<a href=\"grok_help.php?file=ttl_help\" TARGET=\"TTL Help\"><img src=\"images/help1.png\"></a>";
$DTTL_HELP = "<a href=\"grok_help.php?file=ttl_help\" TARGET=\"TTL Help\"><img src=\"images/help1.png\"></a>";
$FROMTO_HELP = "<a href=\"grok_help.php?file=fromto_help\" TARGET=\"Router Help\"><img src=\"images/help1.png\"></a>";
$TIME_HELP = "<a href=\"grok_help.php?file=time_help\" TARGET=\"Time Help\"><img src=\"images/help1.png\"></a>";
$DURATION_HELP = "<a href=\"grok_help.php?file=duration_help\" TARGET=\"Duration Help\"><img src=\"images/help1.png\"></a>";
$MINUTES_HELP = "<a href=\"grok_help.php?file=minutes_help\" TARGET=\"Minutes Help\"><img src=\"images/help1.png\"></a>";
$PROTO_HELP = "<a href=\"grok_help.php?file=proto_help\" TARGET=\"Proto Help\"><img src=\"images/help1.png\"></a>";
$IPADDR_HELP = "<a href=\"grok_help.php?file=ipaddr_help\" TARGET=\"IP Address Help\"><img src=\"images/help1.png\"></a>";
$PORT_HELP = "<a href=\"grok_help.php?file=port_help\" TARGET=\"Internet Service Port Help\"><img src=\"images/help1.png\"></a>";
$RECORDS_HELP = "<a href=\"grok_help.php?file=records_help\" TARGET=\"Record Help\"><img src=\"images/help1.png\"></a>";
$FIELDS_HELP = "<a href=\"grok_help.php?file=fields_help\" TARGET=\"Fields Help\"><img src=\"images/help1.png\"></a>";
$DETAILS_HELP = "<a href=\"grok_help.php?file=details_help\" TARGET=\"Details Help\"><img src=\"images/help1.png\"></a>";
$BYTES_HELP = "<a href=\"grok_help.php?file=bytes_help\" TARGET=\"Bytes Help\"><img src=\"images/help1.png\"></a>";
$LENGTH_HELP = "<a href=\"grok_help.php?file=length_help\" TARGET=\"Length Help\"><img src=\"images/help1.png\"></a>";
$FLAGS_HELP = "<a href=\"grok_help.php?file=flags_help\" TARGET=\"State Flags Help\"><img src=\"images/help1.png\"></a>";
$EXHIBIT_HELP = "<a href=\"grok_help.php?file=exhibit_help\" TARGET=\"PCAP decode Help\"><img src=\"images/help1.png\"></a>";
$VIEW_HELP = "<a href=\"grok_help.php?file=view_help\" TARGET=\"View Help\"><img src=\"images/help1.png\"></a>";
$FREQ_HELP = "<a href=\"grok_help.php?file=freq_help\" TARGET=\"Frequency Help\"><img src=\"images/help1.png\"></a>";
$IMAGE_HELP = "<a href=\"grok_help.php?file=image_help\" TARGET=\"Image Help\"><img src=\"images/help1.png\"></a>";

?>
