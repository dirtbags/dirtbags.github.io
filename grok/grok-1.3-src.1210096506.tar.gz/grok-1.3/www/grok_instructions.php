<?php
$ME="grok";
$SCRIPT_NAME="$ME.php";
  if (file_exists("${ME}_conf.php")) { include ("${ME}_conf.php"); } else { include ("grok_conf.php");}

?>
<!--                             instructions.php                         -->
  <HR>
  </center>
  <a name=instructions></a><p><strong>Hints on using the form</strong><br>
  <p>The various symbols in the logrithmic plot of <b>service requests</b> represent the number of sessions seen per second for a specific protocol/service (as indicated in the legend below the plot, eg. P6S135 is protocol tcp and port 135).  There are normally two of these plots.  The first represents laboratory use of the Internet, while the second indicates incoming requests for services which may or may not be supported.
The <b>external objects</b> plot shows the frequency of five interesting objects.  Depending on how restrictive the collectors BPF filter is you will see more or less overlap of ifpackets and packets.
  <center>
  <table class="h" border="1" style="font-size: 6pt;">
  <tr style="font-size: 6pt;"><th>object</th><th>explanation</th>
  <tr><th class="shaded">ifpackets</th><th>packets per second seen by the ethernet driver</th>
  <tr><th>ifbytes</th><th>bytes per second seen by the ethernet driver</th>
  <tr><th class="shaded">packets</th><th>packets captured by the collector</th>
  <tr><th>consec</th><th>packets processed consecutively before sleeping on a system call</th>
  <tr><th>drops</th><th>packets dropped because the collector is overwhelmed</th>
  </table>
  </center>
  <p>You can ask <strong>grok</strong> to search for a specific pattern (like: "GET "), by entering it's hexidecimal representation with the pattern <strong>47455420</strong> in the sent or received content fields.  The search is anchored at the beginning of the protocols data section if you select '^'.
  <p>
<?php
 print ("The Services plot is based on the number of sessions seen every $RB_CAP_MINUTES minutes, not packets.");
?>
  <p>Please specify the values for fields of interest in the form (found above the plots), and then, if you have not selected a start time, select a starting point on the image or otherwise click the SUBMIT button.  If a start time is not selected, then the the search begins with the most recent session data.  Most of the fields have special help buttons that look like a square with a question mark inside.  You can use the checkbox in front of a field to indicate that packets with that characteristic should not be displayed. 'NOT any' only has meaning in relation to the two 'Content' fields.<br> Bag sessions are written to the current session file after some period of inactivity.  Consequently, you might notice that some tcp sessions have a start time prior to the times indicated in this paragraph when looking at the most recent time slot.
  <p>If you want a glimpse underneath the hood click <a href="info/" >here</a>.
  <p>Bag is the packet capture engine which generates the
<?php
echo $RB_CAP_MINUTES;
?>
 minute pcap and session files.
It has a man page <a href="info/bag.html">here</a>.
