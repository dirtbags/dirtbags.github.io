<?php
$ME="grok";
//$DEBUG = "debug: $ME, ";
$DEBUG = "";
// if ($DEBUG) error_reporting(E_ALL);

$SCRIPT_NAME="$ME.php";
srand();
$rand = rand();
if (file_exists("${ME}_conf.php")) { include ("${ME}_conf.php"); } else { include ("grok_conf.php");}
if (file_exists("${ME}_func.php")) { include ("${ME}_func.php"); } else { include ("grok_func.php");}
if (file_exists("${ME}_hextable.php")) { include ("${ME}_hextable.php"); } else { include ("grok_hextable.php");}
if (file_exists("${ME}_bag_format.php")) { include ("${ME}_bag_format.php"); } else { include ("grok_bag_format.php");} 
include ("grok_auth.php");
// loop to wait for things to settle
openlog ("      $ME()", LOG_ODELAY, LOG_LOCAL1);
if (validate() > 0) {exit (0);}
$tline = "";
$x = 1;
while (!$tline && $x < 2)
{
  include ("gettimes.php");
  if ($seconds_and_some[0] == "") { sleep($x); $x *= 2; }
}
if (!$tline)
{
  include ("broken.html");
  exit(0);
} else {
  $current_time = getdate ($current); # getdate returns ass array  
  $oldest_time = getdate ($first_time); # getdate[0] is an integer
}
$Sessions_Button_x =  $_POST["Sessions_Button_x"];
$Packets_Button_x =  $_POST["Packets_Button_x"];
$Submit = $_POST["Submit"];

if ("$Packets_Button_x" == "" && "$Sessions_Button_x" == "" && "$Submit" == "" )
{

if (file_exists("${ME}_refresh.php")) { include ("${ME}_refresh.php"); } else { include ("grok_refresh.php");} 
if (file_exists("${ME}_preamble.php")) { include ("${ME}_preamble.php"); } else { include ("grok_preamble.php");} 
if (file_exists("${ME}_form_main.php")) { include ("${ME}_form_main.php"); } else { include ("grok_form_main.php");} 
}
else
{
/*
 * Here is where we processes the form values
 * Using objects per second  (packets_button) will cause a different
 * outcome in the future > 9/13/04.  Namely, the stats files will be
 * used to present choices by running tcpslice to find a section of
 * time to generate session information using bag, and not the .sess
 * files.
 */
 if (file_exists("${ME}_form_head.html")) { include ("${ME}_form_head.html"); } else { include ("grok_form_head.html");}
  if ($Packets_Button_x > 0) {
    $X = $Packets_Button_x;
    $Y= $_POST["Packets_Button_y"];
    $view = "Packets";
  } else {
    $X = $Sessions_Button_x;
    $Y= $_POST["Sessions_Button_y"];
    $view = $_POST["VIEW"];
  }
  print "<title>$view: $rand</title>\n</head>\n<body>\n";
  if (!$Y)
  {
    $want = $almost; // maybe, Time: might be selected
  } else
  {
    $X -= 84;
    $factor = 0.40 * ($RB_SECONDS / 60);
    $max = ($factor * ($RB_NUM_SNIPPITS)) - 1;
    if ($X < 0) { $X = 0; }
    if ($X > $max ) { $X = $max; }
    $x = ceil($X / $factor);
    $want = ($almost - 86400) + ($x * $RB_SECONDS);
  }
  if ( $DEBUG) { syslog (LOG_DEBUG, "view: $view, $rand, x=$x");}
  if ( $DEBUG) { syslog (LOG_DEBUG, "X,Y=$X,$Y, max=$max,  want=$want");}
  $wantbase = $want;


/*
 * parse the grok user input
*/

  if (file_exists("${ME}_parse.php")) { include ("${ME}_parse.php"); } else { include ("grok_parse.php");}

#  $requester = getenv("HTTP_X_FORWARDED_FOR");
#  if ("$requester") {
#    $result = get_login_userID($requester);
#    syslog (LOG_DEBUG, "***************************************************");
#    syslog (LOG_DEBUG, "requester = $result@$requester");
#    $r = ZnumAuth ($result);
#    if ("$r" == "") {
#      exit (1);
#    }
#  } else {
#    syslog (LOG_DEBUG, "***************************************************");
#    syslog (LOG_DEBUG, "HTTP_X_FORWARDED_FOR not defined");
#    exit (1);
#  }

  if ($DEBUG) {syslog (LOG_DEBUG, "debug: starttime: $starttime, wantbase: $wantbase");}
  if (!$starttime) $starttime = $wantbase;
/*
 * It's time to do something real:
 */
  if ($specialcriteria)
  { /* not enabled yet */
    #$criteria = "$criteria { i++; if (something) print something}";
  }
  if ($values)
  {
    $values = "{ if ($values) print }";
  }
  if (!$values && !$criteria)
  {
    $values = "{print}";
  }
/*
 * All fields accounted for
 */
   if ($DEBUG) { syslog (LOG_DEBUG, "sflags are: $nsflags, $sflags");}
   if ($DEBUG) { syslog (LOG_DEBUG, "dflags are: $ndflags, $dflags");}
   if ($DEBUG) { syslog (LOG_DEBUG, "values is: $values");}
   if ($DEBUG) { syslog (LOG_DEBUG, "criteria is: $criteria");}
   if ($DEBUG) { syslog (LOG_DEBUG, "format is: $format");}
   if ($DEBUG) { syslog (LOG_DEBUG, "starttime is: $starttime");}
   if ($DEBUG) { syslog (LOG_DEBUG, "minutes is: $minutes");}
   if ($DEBUG) { syslog (LOG_DEBUG, "proto is: $proto");}
   if ($DEBUG) { syslog (LOG_DEBUG, "srchost is: $srchost");}
   if ($DEBUG) { syslog (LOG_DEBUG, "length is: $length");}
   if ($DEBUG) { syslog (LOG_DEBUG, "srcport is: $srcport");}
   if ($DEBUG) { syslog (LOG_DEBUG, "dsthost is: $dsthost");}
   if ($DEBUG) { syslog (LOG_DEBUG, "dstport is: $dstport");}
   if ($DEBUG) { syslog (LOG_DEBUG, "bpf is: $bpf");}
   if ($DEBUG) { syslog (LOG_DEBUG, "scontent is: $scontent");}
   if ($DEBUG) { syslog (LOG_DEBUG, "dcontent is: $dcontent");}
   if ($DEBUG) { syslog (LOG_DEBUG, "tolink is: $tolink");}
   if ($DEBUG) { syslog (LOG_DEBUG, "fromlink is: $fromlink");}
   if ($DEBUG) { syslog (LOG_DEBUG, "details is: $details");}
   if ($DEBUG) { syslog (LOG_DEBUG, "duration is: $duration");}
   if ($DEBUG) { syslog (LOG_DEBUG, "view is: $view");}

  if (!$starttime)
  {
    $starttime = $wantbase;
  }
  $pre_ixmax = ($minutes == 0) ? 1 : intval((($minutes) + ($RB_CAP_MINUTES - 1)) / $RB_CAP_MINUTES );
  if ($DEBUG) {syslog (LOG_DEBUG, "snippit_info $starttime $pre_ixmax");}
  $ls = popen ("$RB_BIN_DIR/snippit_info $starttime $pre_ixmax", "r");
  $useme_ix=0;
  $found=0;
  while (!feof ($ls) && ($useme_ix < $pre_ixmax ))
  {
    $line = fgets ($ls, 255);
    if (strlen($line) > 0) {
      $line = rtrim ($line);
      list ($junk, $useme[$useme_ix], $junk) = split (" ", $line);
  if ($DEBUG) {syslog (LOG_DEBUG, "useme[$useme_ix] = '$useme[$useme_ix].stat'");}
      $found++;
    }
    $useme_ix++;
  }  
  pclose ($ls);
  if ($Packets_Button_x || "$view" == "Packets") /* Snippit presentation */
  {
  if ($DEBUG) {syslog (LOG_DEBUG, "In Snippit grok");}
  if ($DEBUG) {syslog (LOG_DEBUG, "found is $found");}
  if ($DEBUG) {syslog (LOG_DEBUG, "In Snippit mode, Packets_Button_x is $Packets_Button_x");}
  if ($DEBUG) {syslog (LOG_DEBUG, "debug: minutes are $minutes, granularity is $granularity");}
    $so_many_secs = $minutes * 60;
    $nsnips = $granularity / $RB_STAT_PERIOD;
    if (!$nsnips) $nsnips = 1;
    if ($so_many_secs == 0) {$so_many_secs = $granularity;}
    $s=0;
    for ($n=0,$i=0; (($i<$found) && ($n < $so_many_secs)); $i++)
    {
      $file = "$RB_STAT_DIR/$useme[$i].stat";
  if ($DEBUG) {syslog (LOG_DEBUG, "debug: $i, $file");}
      $stats = popen ("sed -n -e 's/^S://p' < $file", "r");
      while (!feof ($stats) && $n < $so_many_secs)
      {
        $tmp = fgets ($stats, 512);
        if (!$tmp) { break; }
        $tmp = substr ($tmp, 0, (strlen($tmp) - 1));
        list ($pstart[$s], $processed[$s], $pkts_dropped[$s], $pkts_total[$s],
              $pkts_ignored[$s], $dev_inpkts[$s], $dev_inbytes[$s],
              $in_bytes[$s], $polls[$s], $ring_ix[$s], $consec[$s],
              $specious[$s], $elapsed[$s]) = split(" ",$tmp,13);
        $s++;
      }
      pclose ($stats);
    }
    if (file_exists("${ME}_pkts.php")) {
      printf ("<form target=\"$rand\" action=\"%s_pkts.php\" method=\"post\">\n", $ME);
    } else {
      printf ("<form target=\"$rand\" action=\"grok_pkts.php\" method=\"post\">\n", $ME);
    }
?>
  <center>
  <table border="0" bgcolor="#88DDFF"><tr><td>
    <table>
<?php
    print "<code>The Details variable limits the number of packets extracted.  If you set details to <strong>all</strong> for decodeip, tcpdump, or bag you might want to include a bpf filter to limit output.  Set it to <strong>all</strong> if you want the whole shebang.</code><hr>\n";
    print "<code>Decode:</code><select STYLE=\"color: blue;\" size=\"1\" name=\"exhibit\">";
    $sp = "      ";
    foreach ($pdcodes as $value)
      if ($value == $exhibit) print "$sp<option selected>$value</option>\n";
      else print "$sp<option>$value</option>\n";
    print "$sp</select>\n";
    print " <code>Details:</code><input style=\"color: blue;\" type=\"text\" name=\"details\" size=\"5\" value=\"$details\">";
    print " <code>Protocol:</code><input style=\"color: blue;\" type=\"text\" name=\"proto\" size=\"5\" value=\"\">";
    print " <code>Source IP:</code><input style=\"color: blue;\" type=\"text\" name=\"src\" size=\"15\" value=\"\">";
    print " <code>Port:</code><input style=\"color: blue;\" type=\"text\" name=\"sport\" size=\"5\" value=\"\">";
    print " <code>Destination IP:</code><input style=\"color: blue;\" type=\"text\" name=\"dst\" value=\"\" size=\"15\">";
    print " <code>Port:</code><input style=\"color: blue;\" type=\"text\" name=\"dport\" value=\"\" size=\"5\"><br>";
    print "<hr><center><code>bpf filter</code></center><input style=\"color: blue;\" type=\"text\" name=\"bpf\" value=\"$bpf\" size=\"166\" maxlength=\"400\">\n";
    $sru = 'alert udp $HOME_NET any -> any 1234 (msg: test; YOU_need_to_modify_this_area_of_the_rule: NOW; classtype: testing; sid:40000; rev:1;)';
    $sru = '';
    print "<hr><center><code>decoder stuff</code></center><input style=\"color: blue;\" type=\"text\" name=\"sru\" value=\"$sru\" size=\"166\" maxlength=\"400\">\n";
?>
    <code>Nosehair:</code>
    <select STYLE="color: blue; font-size: 8pt;" size="1" name="wfcmod">
<?php
    foreach ($wfcmods as $value)
      if ($value == "") print "<option selected>$value</option>";
      else print "<option>$value</option>";
    print "</select>\n";
?>
    <code>Smacqq:</code>
    <select STYLE="color: blue; font-size: 8pt;" size="1" name="smacqqmod">
<?php
    foreach ($smacqqmods as $value)
      if ($value == "") print "<option selected>$value</option>";
      else print "<option>$value</option>";
    print "</select>\n";
?>
    <code>Bro:</code>
    <select STYLE="color: blue; font-size: 8pt;" size="1" name="bromod">
<?php
    foreach ($bromods as $value)
      if ($value == "") print "<option selected>$value</option>";
      else print "<option>$value</option>";
    print "</select>\n";
?>
    </table>
    </td></tr>
    </table>
    </center>
<?php
    if (file_exists("${ME}_stat-table.html")) { include ("${ME}_stat-table.html"); } else { include ("grok_stat-table.html");}
    print ("<tbody>\n");
    $i = 0;
  if ($DEBUG) {syslog (LOG_DEBUG, "$i less than $s");}
    while ($i < $s)
    {
      $count = 0;
      $duration = 0;
      for ($k=0;$k < $nsnips;$k++) {
        $duration += $elapsed[$i+$k];
        $count += $processed[$i+$k];
      }
      $endtime = bcadd("$pstart[$i]", "$duration", 6);
  if ($DEBUG) {syslog (LOG_DEBUG, "$pstart[$i], $duration, $endtime");}
      $tstart = date("M d H:i:s",$pstart[$i]);
      if ($pkts_dropped[$i] > 0) {
        $dropped = "<font color=red>$pkts_dropped[$i]</font>";
      } else {
        $dropped = "$pkts_dropped[$i]";
      }
      $rand = rand();
      #$tstart ="<td><button name=\"foo\" style=\"font-size: 8pt\" value=\"time=$pstart[$i]&endtime=$endtime&count=$count&length=$length&proto=$proto&src=$src&dst=$dst&sport=$srcport&dport=$dstport&view=$view&bpf=$bpf&sru=$sru\" REL=\"external\" TARGET=\"$rand\">$tstart</a><br>";
      $rowcolor = ($i&1) ? "white" : "palegreen";
      $tstart ="<td><button name=\"foo\" style=\"font-size: 8pt; font-style: tt;\" value=\"time=$pstart[$i]&endtime=$endtime&count=$count&length=$length&view=$view\" REL=\"external\" TARGET=\"$rand\">$tstart</a><br>";
      print "<tr bgcolor=\"$rowcolor\" style=\"font-size: 8pt; font-style: tt;\">$tstart<td align=\"right\">$elapsed[$i]<td align=\"right\">$processed[$i]<td align=\"right\">$dropped<td align=\"right\">$pkts_total[$i]<td align=\"right\">$in_bytes[$i]<td align=\"right\">$dev_inpkts[$i]<td align=\"right\">$dev_inbytes[$i]<td align=\"right\">$ring_ix[$i]<td align=\"right\">$consec[$i]<td align=\"right\">$polls[$i]
      </tr>\n";
//     <td align=\"right\">$pkts_ignored[$i]<td align=\"right\">$specious[$i]
      $i++;
    }
    print ("</tbody></table></form>\n");
  }
  else /* Classic grok presentation */
  {
    if ($DEBUG) syslog (LOG_DEBUG, "In Classic grok");
    $nfields = 0;
    if ($format)
    {
    // currently must supply a record count, maybe get it from stats in future
      $records = ($records > 0) ? $records : 10;
      $futts = "| $RB_BIN_DIR/sessionparse -t, -n $records -$format";
      $comma = "";
      $i = 0;
      if ($format == "Z")
      { 
        $nfields = count($Bag_Fields)/2;
        while ($i < $nfields)
        {
          print ("$comma$Bag_Fields[$i]");
          $comma = ",";
          $i ++;
        }
      }
      else
      {
        while (($c = $format[$i]))
        { 
          if (($c != "v") && ($c != "Z") && ($c != "N"))
          {
             print ("$comma$Bag_Fields[$c]");
             $comma = ",";
          }
          $i ++;
        }
      }
      print "<br>\n";
    }
    else
    {
      if ($sflags || $dflags)
      {
        if (!$nsflags) { $nsflags = "0"; }
        if (!$ndflags) { $ndflags = "0"; }
        $sflags = ($sflags) ? sprintf ("-F%s", set_grok_flags ($sflags)) : "";
        $dflags = ($dflags) ? sprintf ("-f%s", set_grok_flags ($dflags)) : "";
  if ($DEBUG) { syslog (LOG_DEBUG, "$RB_BIN_DIR/pwk -M$nsflags -m$ndflags $sflags $dflags");}
        $futts = "| $RB_BIN_DIR/pwk -M$nsflags -m$ndflags $sflags $dflags";
      }
      if (file_exists("${ME}_sess.php"))
      { 
        printf ("<form target=\"$rand\" action=\"%s_sess.php\" method=\"post\">\n", "$ME");
      }
      else
      {
        printf ("<form target=\"_blank\" action=\"grok_sess.php\" method=\"post\">\n");
      }
?>
    <center>
    <table border="0" bgcolor="#88DDFF">
    <tr><td>
    <table border="0" cellspacing="0" style="font-size: 8pt;">
    <strong>Decoder:</strong>
    <select style="color: blue; font-size: 8pt;" size="1" name="exhibit">
<?php
    foreach ($sdcodes as $value)
      if ($value == $exhibit) print "<option selected>$value</option>";
      else print "<option>$value</option>";
?>
    </select>
    <strong>Details: </strong><input style="color: blue;" type="text" name="details" size="5"
<?php
    print "value=\"$details\">";
?>
    </table>
    </td></tr>
    </table>
    </center>
<?php
    if (file_exists("geoipcity.inc")) {
      include ("geoipcity.inc"); 
      $gi = geoip_open("/usr/local/share/GeoIP/GeoIPCity.dat", GEOIP_STANDARD);
    }
      print "<table border=\"0\" <tr><td>\n";
      if (file_exists("${ME}_summary-table.html")) { include ("${ME}_summary-table.html"); } else { include ("grok_summary-table.html");}
      print "<tbody>\n";
    }
   if ($DEBUG) {syslog (LOG_DEBUG, "generating summary table, found is $found");}
    for ($n=0,$i=0; $i<$found; $i++)
    {
     if ($DEBUG) {syslog (LOG_DEBUG, "awk -F, '$criteria $values'");}
      $awk = popen ("awk -F, '$criteria $values' $RB_SESS_DIR/$useme[$i].sess $futts 2>/dev/null", "r");
      while (!feof ($awk))
      {
        if (($records != "all") && ($records > 0) && ($n >= $records)) { break; }
        $tmp = fgets ($awk, 8192);
        if (!$tmp) { break; }
        $tmp = substr ($tmp, 0, (strlen($tmp) - 1));
        if ($format)
        {
          print ("$tmp<br>\n");
          $n ++;
          continue;
        }
        list($start, $duration, $proto, $src, $dst, $srcport, $dstport,
               $sttl, $spkts, $sbytes, $sflags, $sface,
               $dttl, $dpkts, $dbytes, $dflags, $dface,
               $status, $sdata, $ddata) = split(",","$tmp", 21);

        if ("$status" == "800") {continue;}
  
	
        if (file_exists("geoipcity.inc")) {
	  $sgc = geoip_country_code_by_addr ($gi, $src);
	  $dgc = geoip_country_code_by_addr ($gi, $dst);
	} else {
	  $sgc = "";
	  $dgc = "";
        }
if ($DEBUG) { syslog (LOG_DEBUG, "$sgc -> $dgc"); }
        $asflags = grok_flags ($proto, $sflags);
        $adflags = grok_flags ($proto, $dflags);
        $addata = grok_convert ($ddata);
        $asdata = grok_convert ($sdata);
        $tstart = date("M d H:i:s",$start);
	$target = $start+$duration;
        $shex = "<a href=\"grok_unhex.php?time=$start&IPADDR=$src&data=$sdata\" TARGET=\"SDATA $start\">$asdata</a>";
        $dhex = "<a href=\"grok_unhex.php?time=$start&IPADDR=$dst&data=$ddata\" TARGET=\"DDATA $start\">$addata</a>";
        $hsrc = "<a href=\"https://$RB_CSIRT/hostlookup?$src\" TARGET=\"HOSTINFO\">$src</a>";
        $hdst = "<a href=\"https://$RB_CSIRT/hostlookup?$dst\" TARGET=\"HOSTINFO\">$dst</a>";
        $idport = "<a href=\"grok_porthist.php?proto=$proto&service=$dstport&tolink=$linkaddrs[$dface]&fromlink=$linkaddrs[$sface]\" TARGET=\"PORTHIST\">$dstport</a>";
        $tpkts = $spkts + $dpkts;
	list ($secs, $msecs) = explode (".", "$start", 2);
if ($DEBUG) { syslog (LOG_DEBUG, "$secs < $oldest_time[0]"); }
        if ($secs < $oldest_time[0])
        {
          $warn1 = "<p style=\"color: red\">* start times displayed in red have no corresponding data in a pcap file.";
          $tstart = "<td><button name=\"foo\" style=\"color: red; font-size: 8pt;\" value=\"tpkts=0\">$tstart";
        } else
        {
          $warn2 = "<p>Select a Decoder, and click on start time to dig deeper.";
          $endtime = bcadd("$start", "$duration", 6);
  if ($DEBUG) {syslog (LOG_DEBUG, "grok_find_pcap($start) duration=$duration, endtime=$endtime");}
          $rand = rand();
	  $tstart ="<td><button name=\"foo\" style=\"font-size: 8pt; font-style: tt\" value=\"time=$start&endtime=$endtime&tpkts=$tpkts&length=$length&proto=$proto&src=$src&dst=$dst&sport=$srcport&dport=$dstport&view=Sessions\" TARGET=\"$rand\">$tstart";
        }
        $rowcolor = ($n&1) ? "white" : "palegreen";
        print "<tr bgcolor=\"$rowcolor\" style=\"font-size: 8pt; font-style: tt\">$tstart<td>$duration<td align=\"right\">$proto<td>$hsrc<td>$hdst<td align=\"right\">$srcport<td align=\"right\">$idport<td align=\"right\">$sgc<td align=\"right\">$sttl<td align=\"right\">$spkts<td align=\"right\">$sbytes<td align=\"right\">$asflags<td align=\"right\">$linkaddrs[$sface]<td align=\"right\">$dgc<td align=\"right\">$dttl<td align=\"right\">$dpkts<td align=\"right\">$dbytes<td align=\"right\">$adflags<td align=\"right\">$linkaddrs[$dface]<td align=\"right\">$status<td>$shex<td>$dhex</tr>\n";
        $n ++;
      }
      pclose ($awk);
      if (($records > 0) && ($n >= $records)) { break; }
    }

    if (!$format)
    {
      print ("</tbody></table></form>");

      printf ("<p>%d record%s found and printed.\n", $n, ($n == 1) ? "" : "s");
      print ("$warn1$warn2");
      print ("<p>You can find out about the decoders <a href=\"decode_help.html\">here</a>.");
      print ("<p>The state field reflects a merging of the various TCP Flags seen during the session. The value 'AP SF' indicates the normal handshake, exchange of data, and shutdown.<br>Obviously, you will not see TCP Flags for non TCP sessions. However, you may see the 'f' flag which would indicate that some of the session packets were fragmented.");
      print ("<p>If you have questions about the values in any of the session records try clicking on a help button [?] for the variable.<br>");
      print ("I welcome questions regarding grok.  Send them to me <A HREF=\"mailto:cpw@lanl.gov?subject=GROK $GROK_VERSION\">here</a>.<br>");
    } /* end of Classic grok */
  }
}
?>
</body>
</html>
