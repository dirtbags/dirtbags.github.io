
<!--                              grok_preamble.php
-->
<title>GROK3</title>
</head>
<body>
<!--<div class="box"><center><em>grok3 is undergoing major changes, please use grok0</em></center></div> -->
<center><table>
  <tr>
  <th><form action="grok_info.php" method="post" enctype="application/x-www-form-urlencoded" target="Info">
  <table border="0" cellspacing="0" style="font-size: 10pt;">
  <tr><td><button value="incident" type="submit"><font color=chocolate><?php printf ("$GROK Version $GROK_VERSION");?></font></button></td>
  </table>
  </form>
</table></center>
<!--
<center><table>
  <tr>
  <th><form action="https://cynosure.lanl.gov/ticket/incident.html" target="Incident Report">
  <table border="0" cellspacing="0" style="font-size: 10pt;">
  <tr><td><button value="incident" type="submit"><font color=chocolate>Report Incident</font></button></td>
  </table>
  </form>
  <th><form action="https://cynosure.lanl.gov/pipermail/ticket" target="incident">
  <table border="0" cellspacing="0" style="font-size: 10pt;">
  <tr><td><button value="incident" type="submit"><font color=chocolate>View Incidents</font></button></td>
  </table>
  </form>
  <th><form action="https://cynosure.lanl.gov/ticket/analysis.html" target="analysis">
  <table border="0" cellspacing="0" style="font-size: 10pt;">
  <tr><td><button value="analysis" type="submit"><font color=chocolate>Perform Analysis of Incident</font></button></td>
  </table>
  </form>
</table></center>
-->
