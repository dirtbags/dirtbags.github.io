#!/usr/bin/perl

use POSIX qw(strftime);
require "getopts.pl";
require "/home/grok/www/rb_include.pl";

$me = "genpstats.pl";
@Usage = (
        "",
        "\tUsage:\t$0 [",
        "\t\t-h     help",
        "\t\t]"
        );

Getopts("hd");
if ($opt_h) {
  foreach (@Usage)
  {
    printf stderr "$_\n";
  }
  exit (0);
}

open (LIST, "$RB_DATA_DIR/statfile.list") or die "where's statfile.list! $!\n";
$entry = 0;
while (<LIST>) {
    chomp;
    ($ix, $startdate) = split();
    if (!$entry) {
      open (PSTATS, "| pstats > $RB_DATA_DIR/stats") or
                                          die ("where's pstats! $!\n");
    }
    open (STAT, "cat $RB_STAT_DIR/$startdate.stat |") or
					  die ("where's $startdate.stat! $!\n");
    while (<STAT>) {
      print PSTATS;
    }
    close STAT;
    $entry ++;
}
close PSTATS;
close LIST;
open (STATS, "tail -1 $RB_DATA_DIR/stats |") || die ("where's $RB_DATA_DIR/stats! $!\n");
$_ = <STATS>;
close STATS;
chomp;
($packets, $drops) = m/^S:.*, (\d+) packets.*with (\d+) drop/;
if (!$packets) {
  printf stderr "genpstats: ($drops/$packets)!\n";
  exit 1
} else {
  printf "%6.2f%%\n" , ($drops / $packets) * 100;
}
exit 0
