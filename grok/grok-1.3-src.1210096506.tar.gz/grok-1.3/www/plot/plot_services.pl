#!/usr/bin/perl
#        ls -l $SERVICE_PLOT
#
use POSIX qw(strftime);
require "getopts.pl";
require "$ENV{RB_WWW_DIR}/rb_include.pl";

sub use_data {
  my ($face, $check) = @_; 

  $f = 0;
  $F = 0;
  @foo = split ('\|', "$RB_ROUTERS");
  if ($face)
  {
        if ($check < 0) {
        foreach $mac (@foo) {
          $f++;
          if ($face eq "$mac") { $F++; }
        }
        if (!$F) {return 0;}

    } elsif ($check > 0) {
        foreach $mac (@foo) {
          $f++;
          if ($face eq "$mac") { $F++; }
        }
        if ($F) {return 0;}
    } elsif ($check == 0) {
      return 0;
    } else {
        printf stderr "use_data: NO damned good.";
    }
  }
  return 1;
}

$CURRENT_PORTS='last.ports';
$PROGRAM = 'service_plot';
$GNUPLOT_IMAGE = "$RB_DATA_DIR/$PROGRAM.png";
$DELTA = $RB_CAP_MINUTES * 60;

# some gnuplot stuff
$YMAX=0.01;

$NAVY="x000080";
$CORNFLOWER="x6495ED";
$BLUE="x0000FF";
$CYAN="x00FFFF";
$LIGHTBLUE="xADD8E6";
$PURPLE="xA020F0";
$LIGHTPINK="xFFB6C1";
$YELLOW="xFFFF00";
$GOLD="xFFD700";
$GOLDENROD="xDAA520";
$SEAGREEN="x2E8B57";
$GREEN="x00FF00";
$PALEGREEN="x98FB98";
$LIMEGREEN="x7CFC00";
$FOREST="x228b22";
$DARKKHAKI="xBDB76B";
$BROWN="xA52A2A";
$SALMON="xFA8072";
$RED="xFF0000";
$ORANGE="xFFA500";
$PINK="xFF69B4";
$MAGENTA="xFF00FF";
$WHITE="xFFFFFF";
$BLACK="x000000";
$BISQUE="xFFE4C4";
$BACKGROUND=$WHITE;
$BORDER=$BLACK;
$XANDY=$BLACK;

# colors in order of severity?
@colors = ($MAGENTA, $ORANGE, $FOREST, $BLUE,
           $RED, $GOLD, $GREEN, $NAVY,
           $PINK, $BROWN, $LIMEGREEN, $PURPLE,
           $SALMON, $DARKKHAKI, $PALEGREEN, $LIGHTBLUE );

# how to set the order in gnuplot
$order = "$BACKGROUND $BORDER $XANDY";
$device = "png";

# stuff to extract the data
# two arrays
@service_keys = ();
@fields = ();
%frequency = ();
%mnemonic_map = ("P6S80","http/tcp","P17S53","domain/udp","P17S137","netbios-ns/udp",
		"P1S5","redirect/icmp","P6S445","microsoft-ds",
		"P17S123","ntp/udp", "P17S161", "snmp/udp",
		"P1S8","echo/icmp", "P6S1433", "ms-sql-s/tcp",
		"P6S17300","kuang2/tcp", "P17S162","snmptrap/udp",
		"P6S25", "smtp/tcp", "P1S0", "echo_reply/icmp",
		"P6S443", "https/tcp", "P6S554", "rtsp/tcp",
		"P6S139", "netbios-ssn/tcp", "P6S21", "ftp/tcp",
                "P6S20", "ftp-data/tcp", "P1S11", "ttl0/icmp",
		"P17S7", "echo/udp", "P1S3", "unreachable/icmp"); # just leave.

@Usage = (
        "",
        "Usage: $0 [",
        "-V     Version",
	"-T	'Title'",
	"-P	'full path to port histogram file name'",
        "-D	'{incoming,outgoing}'",
        "-S     'SETSIZE'",
        "-s     'day/snip'",
        ""
        );
Getopts("T:P:S:D:s:Vh");
if ($opt_V || $opt_h) {
        printf stderr "plot_services.pl version 0.0.0\n";
        exit (0);
}
if      ("$opt_D" eq "incoming") {
        $check = -1; 
} elsif ("$opt_D" eq "outgoing") {
        $check = 1;
} else                           {
        $check = 0;  
}
if ($opt_S) {
  $SETSIZE="$opt_S,0.7";
}
else {
  $SETSIZE="1.06,0.7";
}

if ($opt_P) {
  $CURRENT_FILE=$opt_P
}
else {
  open FILE, "< $RB_CTRL_DIR/$CURRENT_PORTS" || 
			die "Where is CURRENT_PORTS: $RB_CTRL_DIR/$CURRENT_PORTS!\n";
  $CURRENT_FILE = <FILE>;
  close (FILE);
}
open (CURRENT_PORTS, "<$CURRENT_FILE") ||
			die "Where is CURRENT_FILE: $CURRENT_FILE!\n";

# get the first $RB_SERVICE_PORTS from the current ports histogram
# and save the order in @service_keys
$set_size = 0;
$i = 0;
while (<CURRENT_PORTS>) {
  chomp;
  s/^\s*//;
  ($freq, $proto, $port, $face) = split (/\s/,$_,4);
  if (!use_data($face, $check)) {next;}
  if ($frequency {"${proto} ${port}"}) {next;}
  #printf (stderr "YES, ($check) %s, %s, %s, %s\n", $freq, $proto, $port, $face);
  $service_keys[$set_size] = "${proto} ${port}";
  $frequency {"${proto} ${port}"} = "P${proto}S$port";
  $fields[$set_size] = "P${proto}S$port";
  if ($mnemonic_map{"P${proto}S$port"} )
		{$fields[$set_size] = $mnemonic_map{"P${proto}S$port"};
  }
  $order .= " $colors[$i++]";
  $set_size ++;


  if ($set_size > $RB_SERVICE_PORTS) {last;}
}
close(CURRENT_PORTS);

if ($opt_s) {
  $last = $opt_s;
} else {
  open (LASTSTAT, "snippit_info last |") || die "$me: last.stat, $!\n";
  ($ix, $last) = split(<LASTSTAT>);
  #$last = split (/\./, $last);
}
$stats = "$RB_STAT_DIR/$last.stat";
#printf stderr "stats is $stats\n";

$GNUPLOT_DATAFILE = "$RB_DATA_DIR/$PROGRAM.data";
open (DATA, ">$GNUPLOT_DATAFILE") || die "open: data, $GNUPLOT_DATAFILE, $!\n";
open (INDEX, "<$RB_DATA_DIR/statfile.list") or
                                          die "statfile.list, $!\n";
$index = 0;
$start_dumping = 1;
while (<INDEX>) {
  chomp;
  ($current, $time) = split();
  if ($start_dumping) {
    #print stderr" $RB_DERIVED_DIR/$time.ports\n";
    open (FILE, "< $RB_DERIVED_DIR/$time.ports") or next;
    foreach $key (keys %frequency) {
      $frequency{$key} = 0;
    }
    $set_size = 0;
    while (<FILE>) {
      chomp;
      s/^\s*//;
      ($freq, $proto, $port, $face) = split (/\s/,$_,4);
      if (!use_data($face,$check)) {next;}
  #printf stderr "RB_CAP_MINUTES is $RB_CAP_MINUTES\n";
  #printf stderr "YES, DELTA is $DELTA ($check) %s, %s, %s, %s\n", $freq, $proto, $port, $face;
      $protoport = "$proto $port";
      $freq /= $DELTA;
      if (defined ($frequency {"$protoport"})) {
        $frequency {"$protoport"} += $freq;
        $freq = $frequency {"$protoport"};
        if ($freq > $YMAX) { $YMAX = $freq; }
        $set_size++;
      }
      if ($set_size >= $RB_SERVICE_PORTS) {last;}
    }
    close(FILE);
    $data[$index] = "$time";
    if (!$index) { $INITIAL = "$time"; }
     #printf (stderr "done with $current, index is $index, time is $time, INITIAL is $INITIAL \n");
    for ($i = 0; $i < $RB_SERVICE_PORTS; $i++) {
      $data[$index] .= " $frequency{$service_keys[$i]}";
    }
    print DATA "$data[$index]\n";
    $index++;
  }
  last if ("$last" eq "$current");
}
close(FILE);
if ("$INITIAL" eq "") { $INITIAL = 0; }

if ($start_dumping == 0) { die "start_dumping is 0!\n"; }
$CURRENT_TIME = $time;
open (FILE, "grep S: $stats | tail -1 |") || die "Where is $stats!\n";
$_ = <FILE>;
s/^S\://;
($FINAL, $f2, $f3, $f4, $f5, $f6, $f7, $f8, $f9, $f10, $f11, $f12, $f13) = split ();
s/\..*//;
close FILE;
$FINAL = $FINAL + $f13;

# printf (stderr "FINAL: $FINAL, f13: $f13\n");

close (PORTFILES);
close (DATA);
$GNUPLOT_CTRLFILE = "$RB_DATA_DIR/$PROGRAM.ctrl";
open (CTRL, ">$GNUPLOT_CTRLFILE") ||
			die "Could not open $GNUPLOT_CTRLFILE, $!\n";

($sec,$min,$Hour,$Day,$mon,$Year,$wday,$yday,$isdst) =
						localtime($INITIAL);
($fsec,$fmin,$fHour,$fDay,$fmon,$fYear,$fwday,$fyday,$fisdst) =
						localtime($FINAL);
$hms = sprintf ("%02d:%02d:%02d",$fHour,$fmin,$fsec);
# print stderr "INITIAL: $INITIAL, FINAL: $FINAL, hms: $hms\n";
$fmon += 1;
$HR = ($Hour + ($min / 60)) - 24;
$EHR = $HR + 24;
$TR = ((($CURRENT_TIME-$INITIAL)/3600)+($HR)) - 3;
$TX = ($YMAX) * 5;
$YMAX *= 9.9;

if ($opt_T) {
	$TITLE = $opt_T;
} else {
  $TITLE = "Top $RB_SERVICE_PORTS $opt_D service requests for $fmon/$fDay";
}

print CTRL "set terminal $device $order\n";
print CTRL "set pointsize 0.5\n";
print CTRL "set format y \"%.1e\"\n";
print CTRL "set logscale y\n";
print CTRL "set xlabel \"Hour\"\n";
print CTRL "set ylabel \"sessions per second\"\n";
print CTRL "set yrange [$RB_WWW_MIN:$YMAX]\n";
print CTRL "set xrange [$HR:$EHR]\n";
print CTRL "set xtics 4\n";
print CTRL "set title '$TITLE'\n";
print CTRL "set size $SETSIZE\n";
print CTRL "set key below\n";
print CTRL "set label \"$hms->\" at $TR, $TX\n";

$i = 0;
$sep = "";

printf CTRL "plot";
while ($i < $RB_SERVICE_PORTS) {
  $j = $i + 2; 
  printf CTRL "${sep} '$GNUPLOT_DATAFILE' using (((\$1-$INITIAL)/3600)+($HR)):(\$$j) t \"$fields[$i]\" with points";
  $sep = ", ";
  $i ++;
}
print CTRL "\nquit\n";
close CTRL;

exec "gnuplot $GNUPLOT_CTRLFILE";
exit (0);
