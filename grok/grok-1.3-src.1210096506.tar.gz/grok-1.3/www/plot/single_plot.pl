#!/usr/bin/perl
#
use POSIX qw(strftime);
use Sys::Syslog qw(:standard :macros);

require "getopts.pl";
require "/home/grok/www/rb_include.pl";
#require "$ENV{RB_WWW_DIR}/rb_include.pl";

$SCRIPT="single_plot";
$DEBUG = "$SCRIPT, ";
$DEBUG = "";
@i_routers = split ('\|', "$RB_ROUTERS");
$TRUE = 1;
$FALSE = 0;
$DATA = "data";
$countdown = 20;
if ($DEBUG) {&openlog ($DEBUG, 'ndelay', 'local1');}

sub use_data {
  my ($face, $check) = @_; 

  $f = 0;
  $F = 0;
  @foo = split ('\|', "$RB_ROUTERS");
  if ($face)
  {
        if ($check < 0) {
        foreach $mac (@foo) {
          $f++;
          if ($face eq "$mac") { $F++; }
        }
        if (!$F) {return 0;}

    } elsif ($check > 0) {
        foreach $mac (@foo) {
          $f++;
          if ($face eq "$mac") { $F++; }
        }
        if ($F) {return 0;}
    } elsif ($check == 0) {
      return 0;
    } else {
        printf stderr "use_data: NO damned good.";
    }
  }
  return 1;
}
#sub use_data {
#  local ($face, $check) = @_;
#
#  $RETURN = $FALSE;
#  ROUTER:
#  foreach $internal (@i_routers) {
#
#      if ($check < 0) # incoming
#      {
#        if ("$face" eq "$internal")
#          { 
##if ($countdown-- gt 0) {&syslog ('debug', "incoming $face eq $internal?");}
#		return $TRUE;
#          }
#      }
#      elsif ($check > 0) #outgoing
#      {
#        if ("$face" ne "$internal")
#           {
##if ($countdown-- gt 0) {&syslog ('debug', "outgoing $face eq $internal?");}
#             next ROUTER;
#           }
#        return $TRUE;
#      } else
#      {
##if ($countdown-- gt 0) { &syslog ('debug', "check is $check, face $face internal $internal?"); }
#       return $FALSE;
#      }
#  }
#}

$PROGRAM = 'single_plot';
$GNUPLOT_DATAFILE = "$RB_WWW_DIR/$DATA/$PROGRAM.data";
$GNUPLOT_CTRLFILE = "$RB_WWW_DIR/$DATA/$PROGRAM.ctrl";
unlink $GNUPLOT_DATAFILE, $GNUPLOT_CTRLFILE;
$SET_SIZE_MAX = 1;
$DELTA = $RB_CAP_MINUTES * 60;
$NUM_DAYS = 1;
# some gnuplot stuff
$YMAX=0;

$BACKGROUND=$WHITE;
$BORDER=$BLACK;
$XANDY=$BLACK;
$SETSIZE="1.0225,0.7";

# how to set the order in gnuplot
$order = "$BACKGROUND $BORDER $XANDY";
$device = "png";

# stuff to extract the data
# two arrays
@service_keys = ();
@fields = ();
%frequency = ();
@Usage = (
        "",
        "Usage: $0 [",
        "-V	Version",
        "-h	help",
        "-D	direction(incoming,outgoing)",
	"-T	Title(title)",
        "-p	protocol(number)",
	"-s	service(number)",
	"-n	numdays(number)",
	"	",
	"plot_service -p6 -s554",
        ""
        );

Getopts("n:p:s:D:T:Vh");
if ($opt_n)
{
  $NUM_DAYS = $opt_n;
}
$snips = $NUM_DAYS * $RB_NUM_SNIPPITS;
if ($opt_V || $opt_h) {
        print "version 0.0.0\n";
	foreach (@Usage)
	{
		print "$_\n";
	}
        exit (0);
}
if      ("$opt_D" eq "incoming") {
        $check = -1;
} elsif ("$opt_D" eq "outgoing") {
        $check = 1;
} else                           {
        $check = 0;
}

if ($DEBUG) {&syslog ('debug', "check is $check");}

open (LAST, "$RB_BIN_DIR/snippit_info last |") || die "snippit_info last!\n";
while (<LAST>) {
  chomp;
  ($last, $time) = split(" ");
}
close (LAST);
if ($DEBUG) {&syslog ('debug', "time is $time, last is $last");}
$STATFILE = "$RB_STAT_DIR/$time.stat";
open (PORTFILES, "$RB_BIN_DIR/snippit_info list 86400 $time |") ||
			die "Where are the port files!\n";
$index = 0;
while (<PORTFILES>) {
  chomp;
  ($_, $time) = split(" ");
  $snip = "$RB_DERIVED_DIR/$time";
  $freq = 0;
  $data[$index] = "$time";
  if (!$index) { $INITIAL = $time; }
  open (FILE, "<$snip.ports") || next;
  while (<FILE>) {
    chomp;
    s/^\s*//;
    ($ff, $proto, $port, $face) = split (/\s/,$_,4);
    if (!use_data($face, $check)) {next;}
    if (($proto == $opt_p) && ($port == $opt_s))
    {
    if ($DEBUG)
    {
       &syslog ('debug', "file is $snip.ports")
       &syslog ('debug', "ff=$ff, proto=$proto, port=$port, face=$face, check=$check");
       &syslog ('debug', "use_data says use opt_p=$opt_p opt_s=$opt_s");
    }
      $freq = $ff/$DELTA;
      if ($freq > $YMAX) { $YMAX = $freq; }
      $break;
    }
  }
  close(FILE);
  $data[$index] .= " $freq";
  $index++;
}
close (PORTFILES);

$CURRENT_TIME = $time;
open (FILE, "grep S: $STATFILE | tail -1 |") || die "Where is $snip.stat!\n";
$_ = <FILE>;
s/^S\://;
s/\..*//;
close FILE;
$FINAL = $_;
($fsec,$fmin,$fHour,$fDay,$fmon,$fYear,$fwday,$fyday,$fisdst) =
						localtime($FINAL);
$INITIAL = $FINAL - ($NUM_DAYS * 86400);
($sec,$min,$Hour,$Day,$mon,$Year,$wday,$yday,$isdst) =
						localtime($INITIAL);
$NUM_HOURS = $NUM_DAYS * 24;
$ihms = sprintf ("%02d:%02d:%02d",$Hour,$min,$sec);
$hms = sprintf ("%02d:%02d:%02d",$fHour,$fmin,$fsec);
$fmon += 1;
$HR = ($Hour + ($min / 60)) - $NUM_HOURS;
$EHR = ($fHour + ($fmin/60));
$TX = ((($CURRENT_TIME-$INITIAL)/3600)+$HR) - (2.88 * $NUM_DAYS);
$TY = ($YMAX) * 5;
$YMAX *= 9.9;

if ($opt_T) {
	$TITLE = $opt_T;
} else {
	$TITLE = "P${opt_p}/S${opt_s} activity for the last $NUM_HOURS hours, ending: $fmon $fDay $hms";
}
open (DATA, ">$GNUPLOT_DATAFILE") || die "open: $GNUPLOT_DATAFILE, $!\n";
$i = 0;
while ($i < $index)
{
  $_ = $data[$i];
  ($t, $f) = split ();
  if ($t >= $INITIAL)
  {
    print DATA "$_\n";
  }
  $i ++;
}
close (DATA);


open (CTRL, ">$GNUPLOT_CTRLFILE") ||
			die "Could not open $GNUPLOT_CTRLFILE, $!\n";

print CTRL "set terminal $device $order\n";
print CTRL "set format y \"%g\"\n";
print CTRL "set logscale y\n";
print CTRL "set xlabel \"Hour\"\n";
print CTRL "set ylabel \"sessions per second\"\n";
print CTRL "set yrange [$RB_WWW_MIN:$YMAX]\n";
print CTRL "set xrange [$HR:$EHR]\n";
print CTRL "set xtics 4\n";
print CTRL "set title '$TITLE'\n";
print CTRL "set size $SETSIZE\n";
print CTRL "set key below\n";
print CTRL "set label \"$hms->\" at $TX, $TY\n";

$i = 0;
$sep = "";

printf CTRL "plot";
while ($i < $SET_SIZE_MAX) {
  $j = $i + 2; 
  printf CTRL "${sep} '$GNUPLOT_DATAFILE' using (((\$1-$INITIAL)/3600)+$HR):(\$$j) t \"$fields[$i]\" with points";
  $sep = ", ";
  $i ++;
}
print CTRL "\nquit\n";
close CTRL;

exec "gnuplot $GNUPLOT_CTRLFILE";
unlink $GNUPLOT_DATAFILE, $GNUPLOT_CTRLFILE;
exit (0);
