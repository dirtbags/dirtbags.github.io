#!/usr/bin/perl
#
use POSIX qw(strftime);
require "getopts.pl";
require "$ENV{RB_WWW_DIR}/rb_include.pl";

$PROGRAM = 'content_plot';
$TYPE='cont';
$LOCAL_LINK=0;

$CURRENT_TYPES = "last.$TYPE";
$SET_SIZE_MAX = 16;
$DELTA = 300;

# some gnuplot stuff
$YMAX=0;

$NAVY="x000080";
$CORNFLOWER="x6495ED";
$BLUE="x0000FF";
$CYAN="x00FFFF";
$LIGHTBLUE="xADD8E6";
$PURPLE="xA020F0";
$LIGHTPINK="xFFB6C1";
$YELLOW="xFFFF00";
$GOLD="xFFD700";
$GOLDENROD="xDAA520";
$SEAGREEN="x2E8B57";
$GREEN="x00FF00";
$PALEGREEN="x98FB98";
$LIMEGREEN="x7CFC00";
$FOREST="x228b22";
$DARKKHAKI="xBDB76B";
$BROWN="xA52A2A";
$SALMON="xFA8072";
$RED="xFF0000";
$ORANGE="xFFA500";
$PINK="xFF69B4";
$MAGENTA="xFF00FF";
$WHITE="xFFFFFF";
$BLACK="x000000";
$BISQUE="xFFE4C4";
$BACKGROUND=$WHITE;
$BORDER=$BLACK;
$XANDY=$BLACK;
#$SETSIZE="1.0,0.5";
$SETSIZE="1.0225,0.70";
# colors in order of severity?
@colors = ($MAGENTA, $ORANGE, $FOREST, $BLUE,
           $RED, $GOLD, $GREEN, $NAVY,
           $PINK, $BROWN, $LIMEGREEN, $PURPLE,
           $SALMON, $DARKKHAKI, $PALEGREEN, $LIGHTBLUE );

# how to set the order in gnuplot
$order = "$BACKGROUND $BORDER $XANDY";
$device = "png";

# stuff to extract the data
# two arrays
@type_keys = ();
@fields = ();
%frequency = ();
#%mnemonic_map = ("47455420","web-get", "504f5354", "web-post",
#		"16030000", "https", "1b000000", "ntp3c", "4f505449", "RTVideo",
#		"45484c4f", "email", "30818902", "snmp", "0b000000", "ntp3a",
#		"01000000", "ms-streaming",
#		"01000010","ms-ns"); # just leave this dangling here.
%mnemonic_map = ("","");

@Usage = (
        "",
        "Usage: $0 [",
        "-V     Version",
	"-T	'Title'",
	"-L     'xxxx'	Set local router link interface",
	"-I     Generate data based on incoming traffic.",
	"-O     Generate data based on outgoing traffic.",
        ""
        );

Getopts("S:G:P:L:T:IOVh");

if ($opt_V || $opt_h) {
        printf stderr "$PROGRAM version 0.0.0\n";
        foreach (@Usage) {
          print "$_\n";
        }
        exit (0);
}
if (!$opt_S) {
  printf stderr "$PROGRAM requires '-S <suffix>' two identify ctrl and data files\n";
  exit (1);
}

$GNUPLOT_DATAFILE = "$RB_DATA_DIR/$PROGRAM-$opt_S.data";
$GNUPLOT_CTRLFILE = "$RB_DATA_DIR/$PROGRAM-$opt_S.ctrl";
$GNUPLOT_IMAGE = "$RB_DATA_DIR/$PROGRAM-$opt_S.png";

if ($opt_I && !$opt_L) {
	printf stderr "I[ncoming] option requires L option\n";
	exit (1);
}

if ($opt_O && !$opt_L) {
	printf stderr "O[utgoing] option requires L option\n";
	exit (1);
}

$LINK_LOCAL = $opt_L;

if ($opt_G) {
  $RB_DATA_DIR = $opt_G;
}

if ($opt_P) {
  $CURRENT_FILE = $opt_P;
}
else {
  open FILE, "< $RB_DATA_DIR/$CURRENT_TYPES" ||
			die "Where is $RB_DATA_DIR/$CURRENT_TYPES!\n";
  $CURRENT_FILE = <FILE>;
  close (FILE);
}
open (CURRENT_TYPES, "<$CURRENT_FILE") ||
			die "Where is $CURRENT_FILE!\n";

# get the first $SET_SIZE_MAX from the current ports histogram
# and save the order in @type_keys
$set_size = 0;
$i = 0;
while (<CURRENT_TYPES>) {
  chomp;
  s/^\s*//;
  if ($LINK_LOCAL) {
    ($freq, $LINK, $type) = split (/\s/,$_,3);
    if ($opt_I) {
      if ($LINK ne $LINK_LOCAL) {next;}
    } else
    {
      if ($LINK eq $LINK_LOCAL) {next;}
    }
  }
  else {
    ($freq, $type) = split (/\s/,$_,2);
  }
  if (!defined $frequency{"$type"}) {
    $type_keys[$set_size] = "${type}";
    $frequency {"$type"} = 0;
    $fields[$set_size] = "x$type";
#  if ($mnemonic_map{"$type"} )
#		{$fields[$set_size] = $mnemonic_map{"$type"};
#  }
 
  $order .= " $colors[$i++]";
  $set_size ++;
  if ($set_size > $SET_SIZE_MAX) {last;}
  }
}
close(CURRENT_TYPES);

open (DATA, ">$GNUPLOT_DATAFILE") || die "open: $GNUPLOT_DATAFILE, $!\n";

open (TYPEFILES, "ls -t $RB_SESS_DIR/[0-9]*/*.stat | tac | sed -e 's/.stat//' |") ||
			die "Where are the stat files!\n";
$index = 0;
while (<TYPEFILES>) {
  chomp;
  $file = $_;
  s/^.*\///;
  $CHIP = $_;
  if (!open (FILE, "<$RB_DATA_DIR/$CHIP.$TYPE")) {next;}
  $set_size = 0;
  
  foreach $key (keys %frequency) {
    $frequency{$key} = 0;
  }

  while (<FILE>) {
    chomp;
    s/^\s*//;
    if ($LINK_LOCAL) {
      ($freq, $LINK, $type) = split (/\s/,$_,3);
      if ($opt_I) {
        if ($LINK ne $LINK_LOCAL) {next;}
      } else
      {
        if ($LINK eq $LINK_LOCAL) {next;}
      }
    } else {
      ($freq, $type) = split (/\s/,$_,2);
    }
    $freq /= $DELTA;
    if (defined ($frequency {"$type"})) {
      if ($frequency {"$type"} > 0) {$set_size--;}
      $frequency {"$type"} += $freq;
      if ($frequency {"$type"} > $YMAX) { $YMAX = $frequency {"$type"}; }
      $set_size++;
    }
    if ($set_size >= $SET_SIZE_MAX) {last;}
  }
  close(FILE);
  open (FILE, "grep S: $file.stat | head -1 |") || die "Where is $file.stat!\n";
  $_ = <FILE>;
  close FILE;
  chomp;
  s/^S\://;
  s/\..*//;
  $time = $_;
  $data[$index] = "$time";
  if (!$index) { $INITIAL = $time; }
  for ($i = 0; $i < $SET_SIZE_MAX; $i++) {
    $data[$index] .= " $frequency{$type_keys[$i]}";
  }
  print DATA "$data[$index]\n";
  $index++;
}
close(FILE);

$CURRENT_TIME = $time;
open (FILE, "grep S: $file.stat | tail -1 |") || die "Where is $file.stat!\n";
$_ = <FILE>;
s/^S\://;
s/\..*//;
$FINAL = $_;
close FILE;

close (TYPEFILES);
close (DATA);
open (CTRL, ">$GNUPLOT_CTRLFILE") ||
			die "Could not open $GNUPLOT_CTRLFILE, $!\n";

($sec,$min,$Hour,$Day,$mon,$Year,$wday,$yday,$isdst) =
						localtime($INITIAL);
($fsec,$fmin,$fHour,$fDay,$fmon,$fYear,$fwday,$fyday,$fisdst) =
						localtime($FINAL);
$hms = sprintf ("%02d:%02d:%02d",$fHour,$fmin,$fsec);
$fmon += 1;
$EHR = ($Hour + ($min / 60));
$HR = $EHR - 24;
$TR = ((($CURRENT_TIME-$INITIAL)/3600)+$HR) - 3;
$TX = $YMAX * 6;
$YMAX *= 9.9;

# generic title, most likely need to set with -T option
if ($LINK_LOCAL) {
  $TITLE = ($opt_I) ? "Incoming, Top $SET_SIZE_MAX Type: $TYPE for $fmon/$fDay"
		    : "Outgoing, Top $SET_SIZE_MAX Type: $TYPE for $fmon/$fDay";
}
else {
  $TITLE = "Top $SET_SIZE_MAX Type: $TYPE for $fmon/$fDay";
}

if ($opt_T) {
	$TITLE = $opt_T;
}

print CTRL "set terminal $device $order\n";
print CTRL "set pointsize 0.4\n";
print CTRL "set format y \"%g\"\n";
print CTRL "set logscale y\n";
print CTRL "set xlabel \"Hour\"\n";
print CTRL "set ylabel \"sessions per second\"\n";
print CTRL "set yrange [$RB_WWW_MIN:$YMAX]\n";
print CTRL "set xrange [$HR:$EHR]\n";
print CTRL "set xtics 4\n";
print CTRL "set title '$TITLE'\n";
print CTRL "set size $SETSIZE\n";
print CTRL "set key below\n";
print CTRL "set label \"$hms->\" at $TR, $TX\n";

$i = 0;
$sep = "";

printf CTRL "plot";
while ($i < $SET_SIZE_MAX) {
  $j = $i + 2; 
  printf CTRL "${sep} '$GNUPLOT_DATAFILE' using (((\$1-$INITIAL)/3600)+$HR):(\$$j) t \"$fields[$i]\" with points";
  $sep = ", ";
  $i ++;
}
print CTRL "\nquit\n";
close CTRL;

exec "gnuplot $GNUPLOT_CTRLFILE";
exit (0);
