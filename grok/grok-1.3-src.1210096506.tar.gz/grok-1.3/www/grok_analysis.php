<?php
$ME="grok_analysis";
$SCRIPT_NAME="$ME.php";
include "analysis.html";
