<?php

// Prints out a bunch of PHP autoglobals

$vars = Array("_SERVER","_GET","_POST","_COOKIE","_SESSION");

foreach ($vars as $name) {
  echo "<h1>$name</h1>";
    echo "<small><pre>";
      print_r($$name);
        echo "</pre></small>";
	}


