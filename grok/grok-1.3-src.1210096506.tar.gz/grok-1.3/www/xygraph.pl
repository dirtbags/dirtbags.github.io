#!/usr/bin/perl
#
# tygraph.pl
# Create time based plot of y activity on an x axis, where y is any thing
# that can be quantified such as frequency, and x is time.
#
#define X_PIXS 500
#define Y_PIXS 200
#define X_LABEL Hour of Day
#define Y_LABEL Kb requested
#define TITLE Total Load by Hour
#define Y_MAX 8000
#define Y_MIN 0
#define Y_TICK 5
#define Y_SKIP 2
#define GIF_NAME proxyload.gif
use strict;
use Data::Xtab;
use GIFgraph::bars;

my @data = parse_input(STDIN);
my @outputcols = (0..X_MAX); # replace X_MAX with 23 if this is a days worth
my $xtab = new DATA::Xtab(\@data, \@outputcols);

my @graph_data = $xtab->graph_data;
pop @graph_data; # remove the row of totals (or comment out)
my $freqgraph = new GIFgraph::bars(X_PIXS,Y_PIXS); # 500 by 200 pixel graph

$proxygraph->set( 'x_label' => 'X_LABEL',
		  'y_label' => 'Y_LABEL',
		  'title'   => 'TITLE',
		  'y_max_value' => 'Y_MAX',
		  'y_min_value' => 'Y_MIN',
		  'y_tick_value' => 'Y_TICK',
		  'y_label_skip' => 'Y_SKIP' );
print $proxygraph->plot_to_gif('GIF_NAME', \@graph_data);

sub parse_input {
  # parse input file (stdin?)
  #
  my $filename  = shift @_;
  my @returnvalue;
  my ($host, $hour, $bytes);

  open INFILE, $filename || die "couldn't open $filename!";
  while (<INFILE>) {
    # create regular expression to extract the variables
    # this one assumes there is a time and some count in the log at the
    # specified location ...
    $_ = /^(.+?)\s.+?:(..):.+?\s(\d+?)$/;
    # normalize
    ($hour, $bytes) = ($1, $2/1000);
    if ($hour && $bytes) {
      push @returnvalue, [$hour, $bytes ];
    }
  }
  return @returnvalue
}
