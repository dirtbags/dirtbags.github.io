<?php
include "rb_include.php";
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<link type="text/css" rel="stylesheet" href="grok_style.css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<?php
print "<meta HTTP-EQUIV=\"REFRESH\" CONTENT=\"$RB_SECONDS\" URL=\"https://grok3.lanl.gov/grok/$ME.php\">\n";
include "showHelp.html";
?>
