<?php

if (file_exists("${ME}_conf.php")) { include ("${ME}_conf.php"); } else { include ("grok_conf.php");}
if (file_exists("${ME}_func.php")) { include ("${ME}_func.php"); } else { include ("grok_func.php");}

  $file = ImportHTTPVar("file");
  if   ($file == "flags_help"
     || $file == "ipaddr_help"
     || $file == "port_help"
     || $file == "freq_help"
     || $file == "image_help"
     || $file == "fields_help"
     || $file == "proto_help") { $dont_eval=1; }
  print "<html>\n<head><title>HELP $file</title>\n<link type=\"text/css\" rel=\"stylesheet\" href=\"";
  if (file_exists("${ME}_style.css")) { print("${ME}_style.css\">"); } else { print("grok_style.css\">");} 
  print "<link rel=\"icon\" href=\"images/cpw.jpg\"></head>\n<body>\n";
  if ($dont_eval) 
  {
    $help = popen ("cat help/$file.html", "r");
  } else
  {
    $help = popen ("(source $RB_ETC_DIR/grok/RB_README; cat help/$file.html | while read l; do eval echo \$l; done|fmt| $RB_WWW_DIR/sandwich)", "r");
  }
  while (!(feof($help))&&($tmp = fgets ($help, 255)))
  {
    print ("$tmp");
  }
  pclose ($help);
  print "</body>\n</html>\n";
?>
