<?php
  include ("rb_include.php");
  $fd = popen ("$RB_BIN_DIR/snippit_info almostlast", "r");
  if ($fd)
  {
    $lline = split ("[ \.]", chop(fgets ($fd, 128))); pclose ($fd);
    $almost = $lline[1];
  }
  $fd = popen ("$RB_BIN_DIR/snippit_info first", "r");
  if ($fd)
  {
    $fline = fgets ($fd, 128); pclose ($fd);
    preg_match ("/ ([0-9][0-9]*)/", $fline, $matches);
    $first_time = $matches[1];
    $oldest_time = getdate ($first_time);
  }
  $fd = popen ("$RB_BIN_DIR/snippit_info current", "r");
  if ($fd)
  {
    $cline = chop(fgets ($fd, 128)); pclose ($fd);
    $tline = split (" ", $cline, 2);
    $seconds_and_some = split ("\.", $tline[1], 2);
    preg_match ("/ ([0-9][0-9]*)/", $cline, $matches);
    $current = $matches[1];
    $current_time = getdate ($current);
  }
?>
