<?PHP
// begin parsing values from grok home page
  $x = strspn($_POST["FIELDS"], "TJIjPSDHsABFEhdabfeRCcvNZt,V");
  if ($x < strlen ($_POST["FIELDS"])) {
    die ("Format error: TJIjPSDHsABFEhdabfeRCcvNZt,V");
  }
  $format = $_POST["FIELDS"];
  $minutes = $RB_DEFAULT_MINUTES;
  $granularity = 10;
  $now = $current;

  $x = strspn($_POST["SFLAGS"], "fCEUAPRSFZ");
  if ($x < strlen ($_POST["SFLAGS"])) {
    die ("Source Flags error: fCEUAPRSF");
  }
  $sflags = $_POST["SFLAGS"];

  $x = strspn($_POST["DFLAGS"], "fCEUAPRSFZ");
  if ($x < strlen ($_POST["DFLAGS"])) {
    die ("Destination Flags error: fCEUAPRSF");
  }
  $dflags = $_POST["DFLAGS"];

  $bpf = ""; /* good luck on this one */
  $criteria = ""; /* accumulated awk filters */
  $count = ""; /* | /home/cpw/bin/Uniq */
  $records = ""; /* | head $number applied after */
  $nscontent = "";
  $ndcontent = "";
  $exhibit = "DecodeIP";
  for ($field = 0; $field < $field_max; $field++)
  {
    if ($criteria) { $CRITERIA_ANDOR = " && "; } /*we could make this choosable*/
    if ($bpf) { $BPF_ANDOR = "and"; } /*we could make this choosable*/
    $value = chop (($_POST[$session[$field]]));
    //$value = chop (strtolower ($_POST[$session[$field]]));

    $slen = strspn($value, "^,[]/+-:=.<>! ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789");
    if (($slen < strlen ($value)))
    {
      $foo = substr ($value, 0, $slen);
      for ($i=0;$i<$slen;$i++) { $foo[$i] = '_'; }
      die ("!!! slen is $slen, $session[$field]: $value<br>!!! $session[$field]: $foo^ invalid character<br>");
    }
    $error = "";
    $decrement = 0;
    if ( (strlen ($value) > 0) && ($value != "any" )
                         || ($session[$field] == "SCONTENT")
                         || ($session[$field] == "DCONTENT") )
    {
      if ($DEBUG) { syslog (LOG_DEBUG, "$session[$field] = $value");}

      switch ($session[$field]) {
      case "FIELDS":
        /* taken care of earlier */
  	break;
  
      case "TIME": /* look for some date stuff as well as time */
        
	$selected_time = grok_time ($value);

        if (("$Packets_Button_x" == "")) {
  	  $starttime = $selected_time;
  	} 
        if ($DEBUG) { syslog (LOG_DEBUG, "done value is $value, starttime is $starttime");}

        break;

      case "MINUTES":
        if ($value == "" || $value == "any") { $value = "$RB_DEFAULT_MINUTES"; }
        $args = split (":", $value, 2);
        $minutes = check_equal ("Minutes", "0123456789", $args[0]);
        if ( $args[1] > 0 ) { $granularity = $args[1]; }
        if (($minutes > $RB_DEFAULT_MINUTES) && ($want = $current_seg)
	                                     && ($starttime == ""))
        {
          if (("$Packets_Button_x" == ""))
	  {
              $starttime = $now - ($minutes * 60);
  	  } 
        }
        break;
      case "NPROTO":
        $nproto = check_equal ("Protocol", "=<>!", $value);
        break;
      case "PROTO":
        if ($value == "") { $value = "any"; }
        $value = check_equal ("Protocol",
	       "abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ,",
	       $value);
        if ($value == "any")
	{
          $proto == "";
        }
  	else
	{
          if (ctype_alpha($value[0])) { $value = getprotobyname ($value); }
  	  if ($value < 0 || $value > 255) { $value = 6; }
          $proto = $value;
  	}
        if (($value * 1) == $value)
	{
          grok_set_N_criteria (3, $nproto, $value);
        } 
  	break;
      case "NSRC":
        {
        $nsrc = check_equal ("Source IP", "!=or", $value);
	}
        break;

      case "SRC":
        $value = check_equal ("Source IP",
	    ". abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ,",
	    $value);
  	if (ctype_alpha($value[0]))
	{
  	  $value = gethostbyname ($value);
        }
        grok_ipOR (4, $nsrc, $value);
        $srchost = $value;
  	break;
      case "NDST":
        $ndst = check_equal ("Destination IP", "!=", $value);
        break;
      case "DST":
        $foo = check_equal ("or $srchost", "<>!=", $nsrc);
        $value = check_equal ("Destination IP",
	    ". abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ,",
	    $value);
  	if (ctype_alpha($value[0])) { $value = gethostbyname ($value); }
        grok_ipOR (5, $ndst, $value);
        $dsthost = $value;
  	break;
      case "NSPT":
        $nspt = check_equal ("Source Port", "<>!=or", $value);
        break;
      case "SPT":
        $value = check_equal("Source Port",
	                     " abcdefghijklmnopqrstuvwxyz0123456789-,", $value);
  	if (ctype_alpha($value[0]))
	{
          if ($proto == 1) $value = $icmp{$value};
  	  if (defined ($proto)) { $value = getservbyname ($value, $proto); }
          else { $value = getservbyname ($value, "tcp"); }
        }
        grok_portOR (6, $nspt, $value);
        $srcport = $value;
  	break;
      case "NDPT":
        $ndpt = check_equal ("Destination Port", "<>!=", $value);
        break;
      case "DPT":
        $foo = check_equal ("or $srcport", "<>!=", $nspt);
        $value = check_equal("Destination Port",
	                     " abcdefghijklmnopqrstuvwxyz0123456789-,", $value);
  	if (ctype_alpha($value[0]))
	{
  	  if (defined ($proto)) { $value = getservbyname ($value, $proto); }
          else { $value = getservbyname ($value, "tcp"); }
        }
        grok_portOR (7, $ndpt, $value);
  	$dstport = $value;
  	break;
      case "NSCONTENT":
        $nscontent = check_equal ("Source Content", "!^", $value);
        break;
      case "NDCONTENT":
        $ndcontent = check_equal ("Destination Content", "!^", $value);
        break;
      case "SCONTENT":
      case "DCONTENT":
        $content = check_equal ("Content", " .nyabcdef0123456789", $value);
  	if ($session[$field] == "SCONTENT")
	{
  	  $scontent = $content;
          $disp = 19;
          $bang = ($nscontent == "!") ? "!" : "";
          $slide = (!$nscontent) ? '' : "^";
        }
	else
	{
  	  $dcontent = $content;
          $disp = 20;
          $bang = ($ndcontent == "!") ? "!" : "";
          $slide = (!$ndcontent) ? '' : "^";
        }
        if ($content == "any") { $value = ""; }
  	$bunch = split (" ", $value, 32);
  	$tvalue = "";
  	for ($ix = 0; $ix < count ($bunch); $ix++) { $tvalue .= $bunch[$ix]; }
  	if ($tvalue) { $value = $tvalue; }
        $x = strlen ($value);
        if ($x != intval(($x)/2) * 2)
	{
          die ("!!! content: '$value' is not modulo 8 bits<br>\n");
        }
        if (!$bang) 
        {
          if (!strncmp ($content, "any", 3))
          {
             $criteria = grok_set_criteria ($criteria, "$$disp ~/${slide}../");
          } else
            {
            if ($x > 0)
            {
              $criteria = grok_set_criteria ($criteria,
	                                     "$$disp ~/${slide}$value/");
            }
          }
        }
	else
        {
          if ($x == 0 || (!strncmp ($content, "any", 3)))
          {
            $value='$';
            $bang = "";
          }
	  else
          {
            $value = $content;
          }
          $criteria = grok_set_criteria ($criteria,
	                                 "$$disp $bang~/${slide}$value/");
        }
  	break;
      case "RECORDS":
        $records = check_equal ("Records", "al0123456789", $value);
        break;
      case "DETAILS":
        $details = check_equal ("Details", "al0123456789", $value);
        break;
      case "LENGTH":
        $length = check_equal ("Length", "0123456789", $value);
        break;
      case "NSPKT":
        $nspkts = check_equal ("Source Packets", "<>!=", $value);
        break;
      case "NDPKT":
        $ndpkts = check_equal ("Destination Packets", "<>!=", $value);
        break;
      case "SPKT":
        $spkt = check_equal ("Source Packets", "0123456789", $value);
        grok_set_N_criteria (9, $nspkts, $spkt);
        break;
      case "DPKT":
        $dpkt = check_equal ("Destination Packets", "0123456789", $value);
        grok_set_N_criteria (14, $ndpkts, $dpkt);
        break;
      case "NSTTL":
        $nsttl = check_equal ("Source TTL", "<>!=", $value);
        break;
      case "NDTTL":
        $ndttl = check_equal ("Destination TTL", "<>!=", $value);
        break;
      case "STTL":
        $sttl = check_equal ("Source TTL", "0123456789", $value);
        grok_set_N_criteria (8, $nsttl, $sttl);
        break;
      case "DTTL":
        $dttl = check_equal ("Destination TTL", "0123456789", $value);
        grok_set_N_criteria (13, $ndttl, $dttl);
        break;
      case "NSBYTES":
        $nsbytes = check_equal ("Source Bytes", "<>!=", $value);
        break;
      case "NDBYTES":
        $ndbytes = check_equal ("Destination Bytes", "<>!=", $value);
        break;
      case "SBYTES":
        $sbytes = check_equal ("Source Bytes", "0123456789", $value);
        grok_set_N_criteria (10, $nsbytes, $sbytes);
        break;
      case "DBYTES":
        $dbytes = check_equal ("Destination Bytes", "0123456789", $value);
        grok_set_N_criteria (15, $ndbytes, $dbytes);
      break;
      case "FROMLINK":
        $fromlink = $linkaddrs["$value"];
        if ("$fromlink") {
          if ("$fromlink" == "lanl") $fromlink = "$RB_ROUTERS";
          $criteria = grok_set_criteria ($criteria, "$12 ~/^$fromlink\$/");
        }
        break;
      case "TOLINK":
        $tolink = $linkaddrs["$value"];
        if ("$tolink")
          if ("$tolink" == "lanl") $tolink = "$RB_ROUTERS";
          $criteria = grok_set_criteria ($criteria, "$17 ~/^$tolink\$/");
        break;
      case "NDURATION":
        $nduration= check_equal ("DURATION", "<>!=", $value);
        break;
      case "DURATION":
        $duration= check_equal ("DURATION", ".0123456789", $value);
        if (!$duration) { $duration = "0.000000"; }
        grok_set_N_criteria (2, $nduration, $duration);
        break;
      case "DFLAGS":
  	$dflags = check_equal ("DFlags", "fCEUAPRSF", $dflags);
  	break;
      case "SFLAGS":
        $sflags = check_equal ("SFlags", "fCEUAPRSF", $sflags);
        break;
      case "NSFLAGS":
        if ($sflags) {$nsflags = check_equal ("SFlags", "!=", $value);}
        break;
      case "NDFLAGS":
        if ($dflags) {$ndflags = check_equal ("DFlags", "!=", $value);}
        break;
      case "EXHIBIT":
        $exhibit = $value;
        break;
      default:
        die("default reached, new field? '$session[$field]: $content'<br>");
        break;
      }
    }  /* see beginning of switch */
  } 
// end of parsing user supplied values
?>
