<!--                              grok_form_main.php
-->
<form action="<?echo $SCRIPT_NAME?>" method="POST" enctype="application/x-www-form-urlencoded" target="Results">
<center>
<!--<input type=hidden name=location value="">-->
<div class="box">
<table BORDER="0" BGCOLOR="#88DDFF" CELLPADDING="5">
  <tr><td>
  <table border="0" cellspacing="0" style="font-size: 8pt;">
  <tr>
  <td align=right><strong>Time: </strong></td><td><INPUT TYPE="text" STYLE="color: blue; font-size: 8pt;" VALUE="" SIZE="25" NAME="TIME"> <?php printf ("$TIME_HELP</td>"); ?><td>, <INPUT TYPE="text" STYLE="color: blue; font-size: 8pt;" <?php printf (" VALUE=\"%d\" ", $RB_DEFAULT_MINUTES);?> NAME="MINUTES" SIZE="3" MAXLENGTH="10"> <?php printf ("$MINUTES_HELP minutes. </td>");?>
  <td align=right><strong>Records: </strong></td><td><INPUT TYPE="text" STYLE="color: blue; font-size: 8pt;" VALUE="10" NAME="RECORDS" SIZE="4" MAXLENGTH="10"> <?php printf ("$RECORDS_HELP</td>"); ?>
  <td colspan=1 align=right><strong>Protocol: </strong></td><td colspan=2><select STYLE="color: blue; font-size: 8pt;" name="NPROTO"><option>=</option><option>&lt;</option><option>&gt;</option><option>!</option></select><INPUT TYPE="text" STYLE="color: blue; font-size: 8pt;" VALUE="any" NAME="PROTO" SIZE="5" MAXLENGTH="10"> <?php printf ("$PROTO_HELP</td>"); ?>
  </tr>
  <tr>
  <td colspan=1 align=right><strong>Source IP: </strong></td><td colspan=2><select STYLE="color: blue; font-size: 8pt;" NAME="NSRC"><option>=</option><option>!</option><option>or</option></select><INPUT TYPE="text" STYLE="color: blue; font-size: 8pt;" VALUE="any" NAME="SRC" SIZE="15" MAXLENGTH="256"> <?php printf ("$IPADDR_HELP</td>"); ?>
  <td align=right><strong>Port: </strong></td><td><select STYLE="color: blue; font-size: 8pt;" name="NSPT"><option>=</option><option>&lt;</option><option>&gt;</option><option>!</option><option>or</option></select><INPUT TYPE="text" STYLE="color: blue; font-size: 8pt;" VALUE="any" NAME="SPT" SIZE="5" MAXLENGTH="256"> <?php printf ("$PORT_HELP</td>\n"); ?>
  <td align=right><strong>TTL: </strong></td><td><select STYLE="color: blue; font-size: 8pt;" NAME="NSTTL"><option>=</option><option>&lt;</option><option>&gt;</option><option>!</option></select><INPUT TYPE="text" STYLE="color: blue; font-size: 8pt;" VALUE="" SIZE="3" NAME="STTL"> <?php printf ("$STTL_HELP</td>"); ?>
  </tr>
  <tr>
  <td colspan=1 align=right><strong>Destination IP: </strong></td><td colspan=2><select STYLE="color: blue; font-size: 8pt;" NAME="NDST"><option>=</option><option>!</option></select><INPUT TYPE="text" STYLE="color: blue; font-size: 8pt;" VALUE="any" NAME="DST" SIZE="15" MAXLENGTH="256"> <?php printf ("$IPADDR_HELP</td>"); ?>
  <td align=right><strong>Port: </strong></td><td><select STYLE="color: blue; font-size: 8pt;" name="NDPT"><option>=</option><option>&lt;</option><option>&gt;</option><option>!</option></select><INPUT TYPE="text" STYLE="color: blue; font-size: 8pt;" VALUE="any" NAME="DPT" SIZE="5" MAXLENGTH="256"> <?php printf ("$PORT_HELP</td>\n"); ?>
  <td align=right><strong>TTL: </strong></td><td><select STYLE="color: blue; font-size: 8pt;" NAME="NDTTL"><option>=</option><option>&lt;</option><option>&gt;</option><option>!</option></select><INPUT TYPE="text" STYLE="color: blue; font-size: 8pt;" VALUE="" SIZE="3" NAME="DTTL"> <?php printf ("$STTL_HELP</td>"); ?>
  </tr>
  <tr>
  <td colspan=1 align=right><strong>Sent Content: </strong></td><td colspan=2><select STYLE="color: blue; font-size: 8pt;" NAME="NSCONTENT"><option> </option><option>^</option><option>!</option></select><INPUT TYPE="text" STYLE="color: blue; font-size: 8pt;" VALUE="" NAME="SCONTENT" SIZE="36" MAXLENGTH="64"> <?php printf ("$CONTENT_HELP</td>"); ?>
  <td align=right><strong>SFlags: </strong></td><td><select STYLE="color: blue; font-size: 8pt;" name="NSFLAGS"><option> </option><option>=</option><option>!</option></select><INPUT TYPE="text" STYLE="color: blue; font-size: 8pt;" VALUE="" NAME="SFLAGS" SIZE="9" MAXLENGTH="9"> <?php printf ("$FLAGS_HELP</td>"); ?>
  <tr>
  <td colspan=1 align=right><strong>Received Content: </strong></td><td colspan=2><select STYLE="color: blue; font-size: 8pt;" NAME="NDCONTENT"><option> </option><option>^</option><option>!</option></select><INPUT TYPE="text" STYLE="color: blue; font-size: 8pt;" VALUE="" NAME="DCONTENT" SIZE="36" MAXLENGTH="64"> <?php printf ("$CONTENT_HELP</td>"); ?>
  <td align=right><strong>DFlags: </strong><td><select STYLE="color: blue; font-size: 8pt;" name="NDFLAGS"><option> </option><option>=</option><option>!</option></select><INPUT TYPE="text" STYLE="color: blue; font-size: 8pt;" VALUE="" NAME="DFLAGS" SIZE="9" MAXLENGTH="9"> <?php printf ("$FLAGS_HELP</td>"); ?>
  <tr>
  <td align=right><strong>Src Router: </strong></td><td colspan=2><select STYLE="color: blue; font-size: 8pt;" name="FROMLINK"><option> </option> <?php printmne();?></select> <?php printf ("$FROMTO_HELP</td>"); ?>
  <td align=right><strong>Packets: </strong><td><select STYLE="color: blue; font-size: 8pt;" name="NSPKT"><option>=</option><option>&lt;</option><option>&gt;</option><option>!</option></select><INPUT TYPE="text" STYLE="color: blue; font-size: 8pt;" VALUE="" SIZE="7" MAXLENGTH=12 NAME="SPKT"> <?php printf ("$SPKT_HELP</td>"); ?>
  <td align=right><strong>Bytes: </strong><td><select STYLE="color: blue; font-size: 8pt;" name="NSBYTES"><option>=</option><option>&lt;</option><option>&gt;</option><option>!</option></select><INPUT TYPE="text" STYLE="color: blue; font-size: 8pt;" VALUE="" SIZE="7" MAXLENGTH=12 NAME="SBYTES"> <?php printf ("$BYTES_HELP</td>"); ?>
  <tr>
  <td align=right><strong>Dst Router: </strong></td><td colspan=2><select STYLE="color: blue; font-size: 8pt;" name="TOLINK"><option> </option> <?php printmne();?> </select> <?php printf ("$FROMTO_HELP</td>"); ?>
  <td align=right><strong>Packets: </strong><td><select STYLE="color: blue; font-size: 8pt;" name="NDPKT"><option>=</option><option>&lt;</option><option>&gt;</option><option>!</option></select><INPUT TYPE="text" STYLE="color: blue; font-size: 8pt;" VALUE="" SIZE="7" MAXLENGTH=12 NAME="DPKT"> <?php printf ("$SPKT_HELP</td>"); ?>
  <td align=right><strong>Bytes: </strong><td><select STYLE="color: blue; font-size: 8pt;" name="NDBYTES"><option>=</option><option>&lt;</option><option>&gt;</option><option>!</option></select><INPUT TYPE="text" STYLE="color: blue; font-size: 8pt;" VALUE="" SIZE="7" MAXLENGTH=12 NAME="DBYTES"> <?php printf ("$BYTES_HELP</td>"); ?>
  <tr>
  <td align=right><strong>Session Fields: </strong></td><td><INPUT TYPE="text" STYLE="color: blue; font-size: 8pt;" VALUE="" NAME="FIELDS" SIZE="15" MAXLENGTH="20"> <?php printf ("$FIELDS_HELP</td>"); ?>
  <td colspan=1>
  <td align=right><strong>Duration: </strong><td><select STYLE="color: blue; font-size: 8pt;" name="NDURATION"><option>=</option><option>&lt;</option><option>&gt;</option><option>!</option></select><INPUT TYPE="text" STYLE="color: blue; font-size: 8pt;" VALUE="" SIZE="7" MAXLENGTH=12 NAME="DURATION"> <?php printf ("$DURATION_HELP</td>"); ?>
  <td align=right><strong>Decode: </strong></td>
  <td colspan=1><select STYLE="color: blue; font-size: 8pt;" name="EXHIBIT" value="decodeip"><option selected>decodeip</option><option>tcpdump</option><option>snort</option><option>pcap</option><option>bag</option><option>payload</option><option>smacqq</option><option>bro</option><option>nosehair</option><option>OS</option></select><?php printf ("$EXHIBIT_HELP</td>"); ?>
  <tr>
  <td align=right><strong>View: </strong></td>
  <td colspan=2><select STYLE="color: blue; font-size: 8pt;" name="VIEW"><option>Sessions</option><option>Packets</option></select> <?php printf ("$VIEW_HELP</td>"); ?>
  <td align=right><strong>MTU: </strong></td><td><INPUT TYPE="text" STYLE="color: blue; font-size: 8pt;" VALUE="1518" NAME="LENGTH" SIZE="4" MAXLENGTH="6"> <?php printf ("$LENGTH_HELP</td>"); ?>
  <td align=right><strong>Details: </strong></td><td><INPUT TYPE="text" STYLE="color: blue; font-size: 8pt;" SIZE="4" MAXLENGTH="4" VALUE="4" NAME="DETAILS"> <?php printf ("$DETAILS_HELP</td>"); ?>
  </tr>
  <tr valign=bottom>
    <td align=left><br><BUTTON NAME="reset" TYPE="RESET" STYLE="color: red;">Reset Criteria</BUTTON></td>
    <td><BUTTON NAME="scans" type="button" onClick="wopen('https://csirt.lanl.gov/grok3/scans.php', 'popup', 1000, 800)" STYLE="color: green;">Scans</BUTTON></td>
    <td colspan=8 align=right><BUTTON NAME="Submit" Value="yes" TYPE="submit" STYLE="color: blue;">Retrieve Data</BUTTON></td>
    <td><BUTTON NAME="status" type="button" onClick="showStatus()" STYLE="color: green;">Status</BUTTON></td>
    <td><BUTTON NAME="help" type="button" onClick="showHelp()" STYLE="color: green;">Help</BUTTON></td>
  </tr>
  </table>
  </td></tr>
</table>
</div>
<?php
  print "<center>";
  print "$FREQ_HELP";
  print "<a href=\"https://$RB_CSIRT/$HOST/grok_stats.php?head= outgoing from $RB_INTERNAL hosts&snip=$almost&snet=128.165&col=0\" TARGET=\"top100\" onClick=\"wopen('https://$RB_CSIRT/$HOST/grok_stats.php?head= outgoing $RB_INTERNAL hosts&snip=$almost&snet=128.165&col=0\"', 'popup', 300, 300); return false;\">$RB_INTERNAL</a>\n";
  print "<a href=\"https://$RB_CSIRT/$HOST/grok_stats.php?head= outgoing from $RB_EXTERNAL hosts&snip=$almost&snet=204.121&col=0\" TARGET=\"top100\" onClick=\"wopen('https://$RB_CSIRT/$HOST/grok_stats.php?head= outgoing $RB_EXTERNAL hosts&snip=$almost&snet=204.121&col=0\"', 'popup', 300, 300); return false;\">$RB_EXTERNAL</a>\n";
  print "<a href=\"https://$RB_CSIRT/$HOST/grok_stats.php?head= outgoing from $RB_DMZ hosts&snip=$almost&snet=192.65.95&col=0\" TARGET=\"top100\" onClick=\"wopen('https://$RB_CSIRT/$HOST/grok_stats.php?head= outgoing $RB_DMZ hosts&snip=$almost&snet=192.65.95&col=0\"', 'popup', 300, 300); return false;\">$RB_DMZ</a>\n";
  //for ($i=0; $i<$RB_NUM_DAYS; $i++) {
  //  if ($i == "$current_day") {$color = "red";} else {$color = "green";}
  //  print "<a href=\"session_data/$i/${current_seg}-outgoing-services.png\" ><font color=$color>$i</font></a>";
  //}
  //print "$IMAGE_HELP";
  print "<center><input type=\"image\" alt=\"Sorry No Image\" src=\"session_data/outgoing-services.png\" name=\"Sessions_Button\" border=\"0\"></center>";
  print "</center>";
  print "<hr>";
  print "<center>";
  print "$FREQ_HELP";
  print "<a href=\"https://$RB_CSIRT/$HOST/grok_stats.php?head= incoming to $RB_INTERNAL hosts&snip=$almost&dnet=128.165&col=0\" TARGET=\"top100\" onClick=\"wopen('https://$RB_CSIRT/$HOST/grok_stats.php?head= incoming to $RB_INTERNAL hosts&snip=$almost&dnet=128.165&col=0\"', 'popup', 300, 300); return false;\">$RB_INTERNAL</a>\n";
  print "<a href=\"https://$RB_CSIRT/$HOST/grok_stats.php?head= incoming to $RB_EXTERNAL hosts&snip=$almost&dnet=204.121&col=0\" TARGET=\"top100\" onClick=\"wopen('https://$RB_CSIRT/$HOST/grok_stats.php?head= incoming to $RB_EXTERNAL hosts&snip=$almost&dnet=204.121&col=0\"', 'popup', 300, 300); return false;\">$RB_EXTERNAL</a>\n";
  print "<a href=\"https://$RB_CSIRT/$HOST/grok_stats.php?head= incoming to $RB_DMZ hosts&snip=$almost&dnet=192.65.95&col=0\" TARGET=\"top100\" onClick=\"wopen('https://$RB_CSIRT/$HOST/grok_stats.php?head= incoming to $RB_DMZ hosts&snip=$almost&dnet=192.65.95&col=0\"', 'popup', 300, 300); return false;\">$RB_DMZ</a>\n";
  //for ($i=0; $i<$RB_NUM_DAYS; $i++) {
  //  if ($i == "$current_day") {$color = "red";} else {$color = "green";}
  //  print "<a href=\"session_data/$i/${current_seg}-incoming-services.png\" ><font color=$color>$i</font></a>";
  //}
  //print "$IMAGE_HELP";
  print "<center><input type=\"image\" alt=\"Sorry No Image\" src=\"session_data/incoming-services.png\" name=\"Sessions_Button\" border=\"0\"></center>";
  print "</center>";
  print "<hr>\n";
  print "<center>";
 // for ($i=0; $i<$RB_NUM_DAYS; $i++) {
 //   if ($i == "$current_day") {$color = "red";}
 //   else {$color = "green";}
 //   print "<a href=\"session_data/$i/${current_seg}-packets.png\"><font color=$color>$i</font></a>";
 // }
  print "<center><input type=\"image\" alt=\"Sorry, No Image\" src=\"session_data/packets.png\" name=\"Packets_Button\" border=\"0\"></center>";
  print "</center>\n";
  print "</center></form>\n";
