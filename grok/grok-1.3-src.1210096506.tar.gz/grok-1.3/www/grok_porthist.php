<?php
$SCRIPT="grok_porthist";
$DEBUG = "";
$DEBUG = "debug: $SCRIPT, ";

$DATA="data";
#if ($DEBUG)  { $DATA = tmp; error_reporting(E_ALL); }
if ($DEBUG)  { error_reporting(E_ALL); }

if (file_exists("${SCRIPT}_conf.php")) { include ("${SCRIPT}_conf.php"); } else { include ("grok_conf.php");}
if (file_exists("${SCRIPT}_func.php")) { include ("${SCRIPT}_func.php"); } else { include ("grok_func.php");}
include ("grok_auth.php");

global $HTTP_COOKIE_VARS;

if (validate() > 0) {exit (0);}

$proto = ImportHTTPVar("proto");
$service = ImportHTTPVar("service");
$tolink = ImportHTTPVar("tolink");
$fromlink = ImportHTTPVar("fromlink");

if ($DEBUG) { syslog (LOG_DEBUG, "proto=$proto, service=$service, tolink=$tolink, $fromlink=$fromlink");}
$direction = "outgoing";
if ("$tolink" == "lanl") {$direction="incoming";}
if ($DEBUG)  { syslog (LOG_DEBUG, "tolink=$tolink, direction=$direction, $proto/$service"); }
$port = $service;
print "<html><head><title>PORTHIST S${proto}P$port</title>\n";
print "<link rel=\"icon\" href=\"images/cpw.jpg\"></head>\n<body>\n";
print ("<p>A plot of $direction service S${proto}P$port requests,"); 
if ($proto == 6 || $proto == 17)
{
  $application = ($proto == 6) ? "${port}/tcp" : "${port}/udp";
  print " application is $application, ";
  $hd = popen ("grep -v '^#' help/services | grep \"$application\" | head -1", "r");
  $tmp = fgets ($hd, 128);
  pclose ($hd);
  if ("$tmp") {
  } else {
    print (" which is not defined in help/services.  Please send me a definition.<p>");
  }
} else {
  print (" which is not tcp or udp so lets try for protocol.<p>");
  $hd = popen ("grep -v '^#' help/protocols | grep \"^[a-z\-]*[ 	]*$proto.*[A-Z]\" | head -1", "r");
  $p= fgets ($hd, 128);
  pclose ($hd);
  if ("$p") {
    if (!strncmp($p, "icmp", 4)) {
      //$hd = popen ("grep \"^[a-z]*[         ]*$p[    ]\" help/protocols | head -1", "r");
      //$t = fgets ($hd, 128);
      //pclose ($hd);
      print ("<br>$p/ $port<p>");
    } else {
      print ("<br>$p<p>");
    }
  } else {
    print ("<br>unknown protocol $proto<p>");
    print (" which is not defined in help/protocols.  Please send me a definition.<p>");
  }
}
$output = "$DATA/${direction}_${proto}_$service.png";
if (file_exists($output)) {unlink ($output);}
if ($DEBUG)  { syslog (LOG_DEBUG, "popen: $RB_WWW_DIR/plot/single_plot.pl -D $direction -n 1 -p $proto -s $service > $RB_WWW_DIR/$output"); }

$plotout = popen ("$RB_WWW_DIR/plot/single_plot.pl -D $direction -n 1 -p $proto -s $service > $RB_WWW_DIR/$output", "r");

while (!feof ($plotout) && $plotout) {
  $tmp = fgets ($plotout, 8192);
  print $tmp;
}
pclose($plotout);
if ($DEBUG) { syslog (LOG_DEBUG, "plot complete, see $output."); }
print ("<IMG src=\"$output\" alt=\"$output plot\">");
?>

</body>
</html>
