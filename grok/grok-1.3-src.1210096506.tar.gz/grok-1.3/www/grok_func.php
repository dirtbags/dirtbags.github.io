<?php
include ("rb_include.php");

function grok_time ($value)
{
        include ("grok_conf.php");
        include ("gettimes.php");
	$ME = "      grok_time";
	$ME = "";
	$value = chop($value);
if ("$ME") openlog ("$ME", LOG_ODELAY, LOG_LOCAL1);
        if (is_numeric("$value")) {
          $totime = $value;
        } else {
          $totime = strtotime ("$value");
        }
	if ($totime > 0) {
if ("$ME")
        {syslog (LOG_DEBUG, "grok_time, strtotime: value=$value, totime=$totime");}
	  $value = $totime;
	}
        $stuff = split (" [ ]*", $value, 7);
        $nstuff = count ($stuff);
        $x = strspn($value, "abcdefghijklmnopqrstuvwxyz");
	$y = strlen($value);
	if ($x == $y)
	{
	  $nstuff = 0;
	}
	$i = 0;
if ("$ME")
  {syslog (LOG_DEBUG, "nstuff = $nstuff, value is $value, totime is $totime");}
if ("$ME")  while ( $i < $nstuff) {syslog (LOG_DEBUG, "stuff[$i]=$stuff[$i]"); $i++;}
        if ($y == 28) {$nstuff = 1;}
        switch ($nstuff) {
	case 0:
	  if (!strcmp ($value, "now"))
	    { $julian = $now; }
	  else {
	    if (!strcmp ($value, "oldest"))
	      $fd = popen ("$RB_BIN_DIR/snippit_info first", "r");
	      if ($fd)
	      {
	        $fline = fgets ($fd, 128);
	        pclose ($fd);
	        preg_match ("/ ([0-9][0-9]*)/", $fline, $matches);
	        $first_time = $matches[1];
	        $oldest_time = getdate ($first_time);
	      }
	      else
	      { $julian = 0; }
	  }
	  break;

        case 1: // just time entered OK
          $l = strlen ($value);
	  $k = strlen (intval($value) * 1);
	  if (($l == 17) && ($k == 10)) { $value = intval($value); $l = 10; }
          switch ($l) {
          case 32:
            preg_match ("/^([0-9][0-9][0-9][0-9])-([0-9][0-9])-([0-9][0-9])[tT]([0-9][0-9]):([0-9][0-9]):([0-9][0-9])\.[0-9]*-([0-9][0-9]):([0-9][0-9])/i", $value, $m);
//if ($ME) {syslog (LOG_DEBUG, "$m[1], $m[2],$m[3],$m[4],$m[5],$m[6],$m[7],$m[8]");}
            $julian = mktime ($m[4],$m[5],$m[6],$m[2],$m[3],$m[1]);
            break;
          case 10: //`date '+%s'`
  	    $julian = $value;
if ($ME) {syslog (LOG_DEBUG, "case 10: julian is $julian");}
  	    break;
          case 21: //snort alert fmt: 02/03-15:49:56.300878
            preg_match ("/^([0-9][0-9])\/([0-9][0-9])-([0-9][0-9]):([0-9][0-9]):([0-9][0-9])\.[0-9]*/i", $value, $m);
            $julian = mktime (1*$m[3], 1*$m[4], 1*$m[5], 1*$m[1], 1*$m[2],
	                      $current_time["year"]);
            break;
          case 28: //web log fmt: [28/May/2005:15:10:22 -0600]
            preg_match ("/^\[([0-9][0-9])\/([a-z]*)\/([0-9][0-9][0-9][0-9]):([0-9][0-9]):([0-9][0-9]):([0-9][0-9]) -.*/", $value, $m);
           $mon = $m[2];
//if ($ME) {syslog (LOG_DEBUG, "$m[4],$m[5],$m[6],$mon,$m[1],$m[3]");}
            $julian = mktime (1*$m[4], 1*$m[5], 1*$m[6], $month[$mon], 1*$m[1], $m[3]);
            break;
          default:
      	    {
              $value = check_equal ("Time", ":0123456789.", $value);
              $hms = split (":", $value, 3);
              $hms[0] *=1;
              $hms[1] *=1;
              $hms[2] *=1;
              // maintain some sanity
              if ($hms[0] > $current_time["hours"])
	      {
                // must be the previous day
                $current_time = getdate($now - 86400);
              }
              // if minutes are beyond then just set to current and go
              if ($hms[1] > $current_time["minutes"])
              {
                $hms[1] = 1*$current_time["minutes"];
                $hms[2] = 0;
              }
              $julian = mktime ($hms[0], $hms[1], $hms[2], $current_time["mon"],
	                $current_time["mday"], $current_time["year"]);
            }
if ($ME) {syslog (LOG_DEBUG, "default, value=$value, julian = $julian");}
  	    break;
          }
if ($ME) {syslog (LOG_DEBUG, "value=$value, julian = $julian");}

          break;
        case 2: // month/day/year (or year/month/day) hours:minutes:seconds
          $value = check_equal ("Time", " -:\.0123456789", $stuff[1]);
	  $HMS = split ("\.",  $value);
if ($ME) {syslog (LOG_DEBUG, "HMS $HMS[0], $HMS[1], $HMS[2]");}
  	  $hms = split (":", $HMS[0], 3);
	  $MS = split ("-", $HMS[1],2);
	  $TZ = split (":", $MS[1]);
	  $adjust = ($TZ[0] * 3600) - 21600; // fix 21600 to acct for dst
	  
if ($ME) {syslog (LOG_DEBUG, "$hms[0].$hms[1].$hms[2], $MS[0], $MS[1], $TZ[0], $TZ[1], a=$adjust");}
          $dat = split ("[-/.]", "$stuff[0]", 3);
            
          if ($dat[0] > 2000)
          {
            $y = $dat[0];
            $dat[0] = $dat[1];
            $dat[1] = $dat[2];
            $dat[2] = $y;
          } 
          if (!$dat[1]) {$dat[1] = $current_time["mday"];}
          if (!$dat[2]) {$dat[2] = $current_time["year"];}
          if (($dat[2] > 0) && ($dat[2] < 30)) { $dat[2] += 2000; }
if ($ME) {syslog (LOG_DEBUG, "mktime($hms[0], $hms[1], $hms[2], $dat[0],$dat[1],$dat[2]");}
          $julian = mktime(1*$hms[0], 1*$hms[1], 1*$hms[2], 1*$dat[0],1*$dat[1],
	                   $dat[2]);
	  $julian -= $adjust;
          break;
        case 3: // mon day time 
          $stuff[1] = $stuff[1]*1;
          $value = check_equal ("Time", ":0123456789.", $stuff[2]);
          $hms = split (":", $value, 3);
	  $c = count ($hms);
	  if ($c == 1) {$hms[1] = 0; $hms[2] = 0;}
	  if ($c == 2) {$hms[2] = 0;}
	  $m0 = $month["$stuff[0]"];
	  $m1 = $month["$stuff[1]"];
if ($ME) {syslog (LOG_DEBUG, "$hms[0],$hms[1],$hms[2],$m0, $m1");}
          $julian = mktime(1*$hms[0], 1*$hms[1], 1*$hms[2], $month[$stuff[0]],
	                   $stuff[1], $current_time["year"]);
          break;
        case 4: // day mon year time
          $value = check_equal ("Time", ":0123456789.", $stuff[3]);
          $hms = split (":", $value, 3);
          $value = $stuff[0] * 1;
if ($ME) {syslog (LOG_DEBUG, "mktime(1*$hms[0], 1*$hms[1], 1*$hms[2], $stuff[0], $stuff[1], $stuff[2]");}
          if ($value > 2000) {
            $julian = mktime(1*$hms[0], 1*$hms[1], 1*$hms[2], $stuff[1],
			   $stuff[2], $value);
          } else {
            $julian = mktime(1*$hms[0], 1*$hms[1], 1*$hms[2], $value,
			   $stuff[1], $stuff[2]);
          }   
          break;
        case 6: // linux `date` OK or mail date
          $value = check_equal ("Time", ":0123456789.", $stuff[3]);
	  $hms = split (":", $value, 3);
          if ($hms > 2000) {
            $value = check_equal ("Time", ":0123456789.", $stuff[4]);
	    $hms = split (":", $value, 3);
	    $julian = mktime(1*$hms[0], 1*$hms[1], 1*$hms[2], 1*$month[$stuff[2]], 1*$stuff[1], $stuff[3]);
          } else {
	    $julian = mktime(1*$hms[0], 1*$hms[1], 1*$hms[2], 1*$month[$stuff[1]], 1*$stuff[2], $stuff[5]);
          }
          
          break;
        default: // parse error gives you the current
          print "Please send me this time value:<br";
          print "<b>$value</b>.<br>";
          print "Maybe I can add a parse for it. For now I'll use the current time.<br>";
  	  $julian = $now;
        break;
        }
if($ME) {syslog (LOG_DEBUG, "returning julian time value $julian");}
        if ($julian != 0)
	{
          $value = $julian;
        }
        else
	{
          printf ("Using current time, error parsing date/time %s<br>\n",
	          $value);
  	  $value = $now;
        }
	if ($value < $oldest_time[0]) {$value = $oldest_time[0];}
	return "$value";
}

function grok_file ($fulname, $filename, $type)
{
      switch ($type) {
      case "pcap":
        $result = sprintf ("$filename processing on hold.");
	break;
      default:
        $s = filesize ($fulname);
        $result = sprintf ("%u byte%s captured to %s.", $s, ($s != 1) ? "s" : "", $filename);
      }
      return "$result";
}

function grok_set_S_criteria ($index, $bang, $value)
{
  GLOBAL $criteria, $bpf;

  // calling program must set terminator (or not) in $value
  switch ($bang)
  {
    case '=':
      $criteria = grok_set_criteria ($criteria, "\$$index ~/^$value/");
      break;

    case '!':
      $criteria = grok_set_criteria ($criteria, "\$$index !~/^$value/");
      break;
    default:
      die ("grok_set_S_criteria: $index, $bang, $value<br>"); 
      break;
  }
  $bpf = grok_set_bpf ($bpf, $bang, $index, $value);
}

function grok_set_N_criteria ($index, $bang, $value)
{
  GLOBAL $criteria, $values, $bpf;

  switch ($bang)
  {
    case '=':
      $criteria = grok_set_criteria ($criteria, "\$$index ~/^$value\$/");
      break;

    case '!':
      $criteria = grok_set_criteria ($criteria, "\$$index !~/^$value\$/");
      break;

    case '<':
    case '>':
      $criteria = grok_set_criteria ($criteria, "\$$index $bang $value");
      break;

    case 'a':
      $values = grok_set_criteria ($values, "\$$index & 0x$value");
      break;
    default:
      die ("grok_set_N_criteria: $index, $bang, $value<br>"); 
      break;
  }
  $bpf = grok_set_bpf ($bpf, $bang, $index, $value);
}

function grok_set_bpf ($curbpf, $bang, $index, $value)
{
  GLOBAL $pkt_fields, $BPF_ANDOR, $curbpf, $bpf;

  $curbpf = $bpf;
  //print "debug: call grok_set_bpf ($curbpf, $bang, $index, $value)<br>";
  $element = "$pkt_fields[$index]";
  $foo = substr ($value, 0, strspn($value, "0123456789."));
  if ($element) {
    switch ($bang)
    {
    case '=':
    break;
    case '!':
    break;
    }
    if (!$curbpf) {
      //print "debug: grok_set_bpf return '$BPF_ANDOR $element $foo'<br>";
      return "$BPF_ANDOR $element $foo";
    } else {
      //print "debug: grok_set_bpf return '$curbpf $BPF_ANDOR $element $foo'<br>";
      return "$curbpf $BPF_ANDOR $element $foo";
    }
  }
  //print "debug: grok_set_bpf element is null<br>";
}

function check_equal ($variable_name, $valid, $value)
{
  GLOBAL $isin, $notin, $or;
  $x = strspn($value, $valid);
  if ($x < strlen ($value)) {
    $foo = substr ($value, 0, $x);
    for ($i=0;$i<$x;$i++) {
      $foo[$i] = '_';
    }
    die ("!!! $variable_name: $value<br>!!! $variable_name: $foo^ invalid: garbage characters, or previous 'or' logic disallows input at this point.<br>");
  }
  if ($value == $isin) { $value = "="; }
  elseif ($value == $notin) {$value = "!"; }
  elseif ($value == $or) {$value = "|"; }
  else { $value = $value; }
  return ($value);
}

function set_grok_flags ($aflags)
{
  GLOBAL $state_flags;

  $len = strlen($aflags);
  $f = 0;
  if ($len > 0)
  {
    $i = 0;
    while ($i<9)
    {
      $chip = substr ($aflags, $i, 1);
      //printf ("$chip %s", $state_flags[$chip]);
      $f = $f|$state_flags[$chip]; 
      $i++;
    }
    //print "<br>";
  } else
  {
    $f = 0;
  }
  return ($f);
}

function grok_flags ($proto, $xflags)
{
  
  GLOBAL $GROK_Flags;

  $value = "";
  $flags = hexdec ($xflags);
  $value .= ($flags & 0x200) ? "H" : "&nbsp;";
  $value .= ($flags & 0x100) ? "f" : "&nbsp;";
  $value .= ($flags & 0x80) ? "C" : "&nbsp;";
  $value .= ($flags & 0x40) ? "E" : "&nbsp;";
  $value .= ($flags & 0x20) ? "U" : "&nbsp;";
  $value .= ($flags & 0x10) ? "A" : "&nbsp;";
  $value .= ($flags & 0x08) ? "P" : "&nbsp;";
  $value .= ($flags & 0x04) ? "R" : "&nbsp;";
  $value .= ($flags & 0x02) ? "S" : "&nbsp;";
  $value .= ($flags & 0x01) ? "F" : "&nbsp;";
  return ($value);
}
function grok_set_criteria ($arg1, $arg2)
{
  GLOBAL $CRITERIA_ANDOR;

  if (!$arg1) {
    //printf ("grok_set_criteria, $CRITERIA_ANDOR($arg2)<br>");
    return "$CRITERIA_ANDOR($arg2)";
  } else {
    //printf ("grok_set_criteria, $arg1$CRITERIA_ANDOR($arg2)<br>");
    return "$arg1$CRITERIA_ANDOR($arg2)";
  }
}

function grok_ipOR ($ix, $n, $value)
{
  GLOBAL $criteria, $CRITERIA_ANDOR;

  $otherix = 1;
  $andor = $CRITERIA_ANDOR;
  $bah = '';
  $i = 0;
  if ($criteria) {$criteria = "$criteria $CRITERIA_ANDOR";}
  $foo = split (',[ ]*', $value);
  $ANDOR = "||";
  if ($n == '!') {
    $bah = $n;
    $ANDOR = "&&";
  }
  if ($n == 'or') {
    $n = '=';
    $otherix = 2 ;
  }
  $criteria = "$criteria(";
  $CRITERIA_ANDOR = "";
  while ($i < $otherix) {
    foreach ($foo as $thing) {
      $chips = split ("\.", $thing, 4);
      $cruft = (ctype_digit ($chips[3])) ? "$" : "";
      grok_set_S_criteria ($ix, $n, "$thing$cruft");
      $CRITERIA_ANDOR = " $ANDOR ";
    }
    $ix ++;
    $i ++;
  }
  $criteria = "$criteria)";
  $CRITERIA_ANDOR = " && ";

}

function grok_portOR ($ix, $n, $value)
{
  GLOBAL $criteria, $CRITERIA_ANDOR;

  $otherix = 1;
  $andor = $CRITERIA_ANDOR;
  $bah = '';
  $i = 0;
  if ($criteria) {$criteria = "$criteria $CRITERIA_ANDOR";}
  $foo = split (',[ ]*', $value);
  $ANDOR = "||";
  if ($n == '!') {
    $bah = $n;
    //$n = '=';
    $ANDOR = "&&";
  }
  if ($n == 'or') {
    $n = '=';
    $otherix = 2 ;
  }
  $criteria = "$criteria(";
  $CRITERIA_ANDOR = "";
  while ($i < $otherix) {
    foreach ($foo as $thing) {
      $chips = split ("\.", $thing, 4);
      $cruft = (ctype_digit ($chips[3])) ? "$" : "";
      grok_set_N_criteria ($ix, $n, "$thing");
      $CRITERIA_ANDOR = " $ANDOR ";
    }
    $ix ++;
    $i ++;
  }
  $criteria = "$criteria)";
  $CRITERIA_ANDOR = " && ";

}

#function grok_make_pcaplist ()
#{
#  GLOBAL $maxtime, $earliest, $pcaptime, $pcapfile, $RB_INDEX, $RB_PCAP_DIR ;
#  GLOBAL $RB_CAP_MINUTES;
#
#  // build an array of start times
#  $i = 0;
#  $expected = 0;
#  $pcapindex = popen ("cat $RB_INDEX", "r");
#  $missing = 0;
#  $ssecs = $RB_CAP_MINUTES * 60;
#  while (!(feof($pcapindex))&&($tmp = fgets ($pcapindex, 255)))
#  {
#      $tmp = substr ($tmp, 0, strlen($tmp) - 1);
#      list ($snip, $time, $micros) = split (" ", $tmp, 3);
#      if (!$expected) {$expected = $time; $earliest = $i;}
#      else {$expected += $ssecs;}
#      $diff = abs($time - $expected);
#      #if ($diff > $ssecs) # go into search mode
#      #{ 
##	 $missing++;
##	 printf ("problem? $expected <> $time<br>");
##	 $expected = $time;
##      }
#      $maxtime = $i;
#      $pcaptime[$i] = $maxtime;
#      $pcapfile[$i] = "$RB_PCAP_DIR/$time.${micros}.pcap";
#      //if ($i < 5 )
#       //printf ("b: %d, %s, %s, %s<br>\n", $i, $pcaptime[$i], $pcapfile[$i], $maxtime);
#      $i ++;
#  }
#  //if ($missing) printf ("data loss of %3.2f found in $RB_INDEX<br>", ($missing/$i)*100);
#  pclose ($pcapindex);
#  return;
#} eee
  
function grok_get_last ($type)
{
  GLOBAL $RB_BIN_DIR, $RB_PCAP_DIR ;

  $p = popen ("$RB_BIN_DIR/snippit_info last", "r");
  if ($p) {
      $l = chop (fgets ($p, 128));
      pclose ($p);
      $a = explode (" ", $l);
      if ($type == "time") {
          return ("$a[1]");
      } else {
          return ("$RB_PCAP_DIR/$a[1].$a[2].pcap");
      }
  }
  return ("");
}

function grok_get_first ($type)
{
  GLOBAL $RB_BIN_DIR, $RB_PCAP_DIR ;

  $p = popen ("$RB_BIN_DIR/snippit_info first", "r");
  if ($p) {
      $l = chop (fgets ($p, 128));
      pclose ($p);
      $a = explode (" ", $l);
      if ($type == "time") {
          return ("$a[1].$a[2]");
      } else {
          return ("$RB_PCAP_DIR/$a[1].pcap");
      }
  }
  return ("");
}

function grok_find_pcap ($arg1)
{
  GLOBAL $RB_BIN_DIR, $RB_PCAP_DIR ;

    $p = popen ("$RB_BIN_DIR/snippit_info $arg1 1", "r");
    if ($p) {
      $l = chop (fgets ($p, 128));
      pclose ($p);
      $a = explode (" ", $l);
      if ("$a[1]") return ("$RB_PCAP_DIR/$a[1].pcap");
    }
    return ("");
}

function ZnumAuth ($znumber)
{
  include ("rb_include.php");

  # returns true if allowed, false if not
  $handle = fopen("$RB_ETC_DIR/grok/users", "r");
  while ($z = fgets($handle))
  {
    if (strncmp ("$znumber", "$z", 6) == 0) return "$z";
  }
  print "Your Znumber ($znumber) is not on the list, contact CSIRT.<br>";
  return "";
}

function validate ()
{
  $requester = getenv("HTTP_X_FORWARDED_FOR");
  if ("$requester")
  {
    $result = get_login_userID($requester);
    syslog (LOG_DEBUG, "*******************************************");
    syslog (LOG_DEBUG, "requester = $result@$requester");
    $r = ZnumAuth ($result);
    if ("$r" == "")
    {
    syslog (LOG_DEBUG, "access denied from {$_SERVER['REMOTE_ADDR']} ({$_SERVER['HTTP_USER_AGENT']}");
      return (1);
    }
  } else {
    syslog (LOG_DEBUG, "***************************************************");
    syslog (LOG_DEBUG, "HTTP_X_FORWARDED_FOR env not defined");
    return(0);
  }
  return (0);
}

function ImportHTTPVar($var_name, $valid_data = "", $exception = "")
{
   GLOBAL $HTTP_POST_VARS, $HTTP_GET_VARS;

   $tmp = "";

   if ( isset($HTTP_POST_VARS[$var_name]) ) 
   {
      $tmp = $HTTP_POST_VARS[$var_name];
      #print "debug: isset HTTP_POST_VARS $var_name is $tmp<br>";
   }
   else if ( isset($HTTP_GET_VARS[$var_name]) )
   { 
      $tmp = $HTTP_GET_VARS[$var_name];
      #print "debug: isset HTTP_GET_VARS $var_name is $tmp<br>";
   }
   else
   {
      #print "debug: $var_name is nada<br>";
      $tmp = "";
   }

   $x = strspn($tmp, "\'$|*,_\\;\":-() <>!=&_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghihjklmnopqrstuvwxyz0123456789./");
   if ($x < strlen ($tmp)) {
      $foo = substr ($tmp, 0, $x);
      for ($i=0;$i<$x;$i++) {
        $foo[$i] = '_';
      }
      die ("ImportHTTPVar: $tmp<br> $tmp: '$foo' invalid character<br>");
    }
   return ($tmp);
}
function printmne()
{
  GLOBAL $linkaddrs, $mnemaccnt;

  $i = 0;
  $ii = 0;
  $iimax=0;
  while ($i < $mnemaccnt)
  {
    $new = 1;
    for ($ii=0;$ii<$iimax;$ii++)
    {
      if ($foo[$ii] == $linkaddrs[$i]) {$new = 0;}
    } 
    
    if ($new)
    {
      $iimax++;
      $foo[$ii++] = $linkaddrs[$i];
      print ("<option>$linkaddrs[$i]</option>"); 
    }
   $i ++;
  }
}
?>
