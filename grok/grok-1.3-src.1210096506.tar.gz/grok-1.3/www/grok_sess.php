<?php
$SCRIPT = "grok_sess";
$DEBUG = "debug: $SCRIPT, ";
$DEBUG = "";
//if ($DEBUG)  error_reporting(E_ALL);

if (file_exists("${SCRIPT}_conf.php")) { include ("${SCRIPT}_conf.php"); } else { include ("grok_conf.php");}
if (file_exists("${SCRIPT}_func.php")) { include ("${SCRIPT}_func.php"); } else { include ("grok_func.php");}
include ("grok_auth.php");

global $HTTP_COOKIE_VARS;

openlog (" $SCRIPT()", LOG_ODELAY, LOG_LOCAL1);

$view="";

$todo = ImportHTTPVar("exhibit");
foreach ($sdcodes as $value){if ("$value" == "$todo"){ $exhibit = $value; break;}}
if ("$exhibit" == "")
{
  print "Sorry, \"$todo\" is not implimented in the Session function.<br>";
  print "You might find it using the Packet view.<br>";
  print "Submit a feature request discussing how this would be useful to you.<br>";
  exit (0);
}
if (validate() > 0) {exit (0);} 

$details = ImportHTTPVar("details");
if ($DEBUG) { syslog (LOG_DEBUG, "todo: $todo, details: $details"); }

// following is for form call
$foo = ImportHTTPVar("foo");
if ("$foo")
{
  $array = split ("&", $foo);
  foreach ($array as $a)
  {
     $tmp = split ("=", $a);
     $$tmp[0] = $tmp[1];
     if ($DEBUG && $tmp[0]) { syslog (LOG_DEBUG, "$tmp[0] = $tmp[1]"); }
  }
} else
{
  $view = ImportHttpVar("view");
  $bpf = ImportHTTPVar("bpf");
  $time = ImportHTTPVar("time");
  $endtime  = ImportHttpVar("endtime");
  $tpkts = ImportHttpVar("tpkts");
  $length = ImportHttpVar("length");
  $proto = ImportHttpVar("proto");
  $src = ImportHttpVar("src");
  $dst = ImportHttpVar("dst");
  $sport = ImportHttpVar("sport");
  $dport = ImportHttpVar("dport");
}
// fudge
$endtime += 1;

$and = "";
if ("$VLAN")
{
  if ("$bpf") $bpf = "'$VLAN and ($bpf)'";
  else $bpf = $VLAN;
  $and = " and ";
  $VLANOFF = "-o 4";
}
else
{
  $VLANOFF = "";
  if ("$bpf") $and = " and ";
}

if ((($exhibit == "payload") || ($exhibit == "pcap")) && ($details == "4")) { $details = "all"; }

if ($DEBUG) {syslog (LOG_DEBUG, "exhibit=$exhibit details=$details bpf=$bpf time=$time endtime=$endtime tpkts=$tpkts length=$length proto=$proto src=$src dst=$dst sport=$sport dport=$dport view=$view");}

if (($tpkts == 0) && ($todo != "pcap"))
{
  print "$SCRIPT: Sorry, the tpkts variable is not set.";
  exit (0);
}

if ($details > 0 || $details == "all")
{
  if ($details == "all") {
     $count = $tpkts;
  }  else {
     $count = ($details > $tpkts) ? $tpkts : $details;
  }
} else {
  print "$SCRIPT: Sorry, Details is blank, consequently the result would be zero packets.<br>";
  print "Contact the developer, if you can think of a good use for zero packets.";
  exit (0);
}
$maxsnips = $RB_NUM_SNIPPITS - 1;
$tcpdswitch = "ttnq";
$portselect = "";
if ($proto == 6 || $proto == 17)
{
  if ("$sport" != "")
  {
    $portselect = "and port $sport ";
  }
  if ("$dport" != "")
  {
    $portselect .= "and port $dport ";
  }
}
$hostselect = "";
if ($src)
  $hostselect = "and host $src";
if ($dst)
  $hostselect = "$hostselect and host $dst";

$protoselect = "$bpf${and}ip";
if ($proto>0)
{
$protoselect = "$protoselect and proto $proto";
$filname = "$time-$proto,$src:$sport,$dst:$dport";
} else
{
 if ($src || $dst)
    $filname = "$time-$src,$dst";
 else
    $filname = "$time-$endtime";
}
$bpf = "$protoselect $hostselect $portselect";
$evaluate = False;
$exh = "$filname.$suffixs[$exhibit]";
$pcapname = "$RB_WWW_DIR/data/$filname.pcap";
$tofilname = "data/$time-$proto,$src:$sport,$dst:$dport.data";
$fromfilname = "data/$time-$proto,$dst:$dport,$src:$sport.data";
$webname = "data/$exh";
$fulname = "$RB_WWW_DIR/$webname";
if ($DEBUG) { syslog (LOG_DEBUG,  "webname = $webname, exh = $exh, fulname = $fulname"); }
if ($DEBUG) { syslog (LOG_DEBUG,  "tofilname = $tofilname, fromfilname = $fromfilname"); }
$slice = "";
list ($e, $y) = split ("\.", $endtime, 2);
$dur = bcsub("$endtime", "$time" ,6);
$ctime = 0;
$result = "";
$tempfile = "";
if (!file_exists("$pcapname"))
{
  # this block gets all releavent data into data/name.pcap, future queries for same
  # will bypass this section.
  if ($DEBUG) {syslog (LOG_DEBUG, "snippit_info list $dur $endtime");}
  $fd = popen ("$RB_BIN_DIR/snippit_info list $dur $endtime", "r");
  if (!$fd)
  {
    syslog (LOG_DEBUG, "snippit_info list $dur $endtime, failed!");
    exit(1);
  }
  else
  {
    $tempfile = tempnam("/tmp", "grok");
    $FILES = "";
    if ($DEBUG) {syslog (LOG_DEBUG, "tempfile is $tempfile");}
    $t = 0; $ctime = 0;
    $tofile = "";
    # this block extracts relevant (bpf) pcap data to a list of pcap files in $FILES
    while (!feof ($fd) && ($ctime < $e) && ($line = chop (fgets ($fd, 128))))
    {
      if ($DEBUG) {syslog (LOG_DEBUG, "line: $line, ctime: $ctime, e:$e");}
      list ($ix, $ntime) = split (" ", $line);
      $unique = trim ("$ntime");
      $file = "$RB_PCAP_DIR/$unique.pcap";
      $firstpass = "$RB_BIN_DIR/tcpslice $unique $endtime";
      $firstpass = "$RB_BIN_DIR/tcpslice $time $endtime 2>/dev/null";
      if ("$tofile") {
        $firstpass = "cat";
      } 
      $tofile = "$tempfile-$unique.pcap";
      $cmd = "$firstpass $file | $RB_BIN_DIR/tcpdump -w $tofile -r - -s $length $bpf 2>/dev/null";
      $FILES="$FILES$tofile ";
      if ($DEBUG) { syslog (LOG_DEBUG, "cmd: \"$cmd\", FILES=$FILES"); }
      $slice = popen ("$cmd", "r");
      while (!feof ($slice) && $slice) { $buf = fgets ($slice, 8192); }
      pclose($slice);
    }
    if (!"$FILES")
    {
      if ($DEBUG) {syslog (LOG_DEBUG, "snippit_info list $dur $endtime failed!");}
      exit(1);
    }
    trim ($FILES);
    $cmd = "($RB_BIN_DIR/pcat $FILES > $pcapname)";
    $slice = popen ("$cmd", "r");
    while (!feof ($slice) && $slice) { $tmp = fgets ($slice, 8192); }
    pclose($slice);
    if (!$DEBUG)
    {
      foreach (split(" ", $FILES) as $file)
      {
        if(is_file($file)) { unlink($file); } 
      }
      if (is_file($tempfile)) { unlink ($tempfile); }
    }
  }
}

if ($todo != "pcap") {
    header("Content-type: text/html");
    print "<html><head><title>Packet time: $time</title>\n";
    print "<link rel=\"icon\" href=\"images/cpw.jpg\"></head>\n<body>\n<pre>\n";
} else {
}
# end of pass to generate pcap stream with supplied bpf to a set of 1 or
# more pcap files which can then be processed for specific exhibit.

if ($exhibit == "OS")
{
    $cmd = "$RB_BIN_DIR/p0f 2>/dev/null -s $pcapname | grep \"$src\"";
    if ($DEBUG) {syslog (LOG_DEBUG, "$exhibit: $cmd");}
    $slice = popen ("$cmd", "r");
    $evaluate = True;
}
else if ($exhibit == "decodeip")
{
    $cmd = "($RB_BIN_DIR/tcpdump -xttqnc $count -s$length $honorcount -r $pcapname |
      sed -e 's/0x[0123456789abcdef:]*//' |
      $RB_BIN_DIR/DecodeIP $VLANOFF -Xl$length)";
    if ($DEBUG) {syslog (LOG_DEBUG, "$exhibit: $cmd");}
    $slice = popen ("$cmd", "r");
    $evaluate = True;
}
else if ($exhibit == "bag")
{
    $cmd = "($RB_BIN_DIR/rbag -s$length $honorcount -r $pcapname -w /dev/null -C'session,ipaddr=on,dcaptlen=128,scaptlen=128' 2>/dev/null)";
    if ($DEBUG) {syslog (LOG_DEBUG, "$exhibit: $cmd");}
    $slice = popen ("$cmd", "r");
    $evaluate = True;
} else if ($exhibit == "snort")
{
    $cmd = "($RB_BIN_DIR/snort -vd -n $count -P $length -r $pcapname 2>/dev/null | $RB_BIN_DIR/trimbrackets)";
    if ($DEBUG) {syslog (LOG_DEBUG, "$exhibit: $cmd");}
    $slice = popen ("$cmd", "r");
    $evaluate = True;
} else if ($exhibit == "tcpdump")
{
    $cmd = "($RB_BIN_DIR/tcpdump -ttttneAc $count -s$length -r $pcapname  2>/dev/null |
      sed -e 's/^[0-9]*-[0-9]*-[0-9]* [0-9]*:[0-9]*:[0-9]*\.[0-9]*/<b>&<\/b>/')";
    if ($DEBUG) {syslog (LOG_DEBUG, "$exhibit: $cmd");}
    $slice = popen ("$cmd", "r");
    $evaluate = True;
} else if ($exhibit == "pcap" || $exhibit == "payload")
{
    # generate the pcapfile
    $pcapfile = "${pcapname}";
    $foo = basename ($pcapfile);
    if ($exhibit == "pcap")
    {
      $mime_type="application/cap";
      header("Content-Type: " . $mime_type);
      header("Cache-Control: public, must-revalidate");
      header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
      header("Pragma: hack");
      header("Content-Length: " .(string)(filesize($pcapfile)) );
      header("Content-Disposition: attachment; filename=" . $foo);
      header("Content-Transfer-Encoding: binary\n");
      $fp = fopen ("$pcapfile", "rb");
      while (!feof($fp) && $fp)
      {
          $buffer = fread($fp, 8192);
          print $buffer;
      }
      fclose ($fp);
      if ($DEBUG) closelog();
      return(0);
    } else # payload 
    {
      if ($proto == "6")
      {
         $cmd = "(cd $RB_WWW_DIR/data;$RB_BIN_DIR/tcpflow -T $time -r '$pcapfile')";
      } else {
         $cmd = "(cd $RB_WWW_DIR/data;$RB_BIN_DIR/mkfile $pcapfile 2>/dev/null)";
      }
      if ($DEBUG) {syslog (LOG_DEBUG, "$exhibit: $cmd");}
      $slice = popen ("$cmd", "r");
      while (!feof ($slice) && $slice)
      {
        $tmp = chop(fgets ($slice, 8192));
        print "$tmp";
      }
      pclose ($slice);
    }
    if (file_exists($tofilname))
      print "To retrieve payload sent from $src hover <a href=\"$tofilname\">here</a> and select \"Save Link As ...\".<br>\n";
    else
      print "No payload sent from $src.<br>\n";
    if (file_exists($fromfilname))
      print "To retrieve payload received from $dst hover <a href=\"$fromfilname\">here</a> and select \"Save Link As ...\".<br>\n";
    else
      print "No payload received from $dst.<br>\n";
}

// evaluate runs the cmd.  If the cmd does not output to $fulname, then
// in addition it parses the data for interesting stuff and may augment it.
// a bad thing
if ($evaluate)
{
    while (!feof ($slice) && $slice) 
    {
      $tmp = chop(fgets ($slice, 8192));
      list ($t,$tos, $gt, $rest) = split (" ", $tmp, 4);
      if ($gt == ">" || $tos == "(tos" || $tos == "Seq:" ||  $tos == "IP" || $t == "ICMP" || $t == "Len:" || $exhibit == "bag" )
      {
        if ($tos == "(tos" || $gt == ">" || $gt == "vlan" ) { $ctime = $t;}
        $count --;
      }
      $tmp =substr ($tmp, 0, (strlen($tmp)));
      print "$tmp<br>";
    }
    pclose ($slice);
   // $result = grok_file ($fulname, $exh, $exhibit);
    
}

// this rearend could be used optionally to do what it does.
// currently some of the above exhibitors comment out $result generation
// which results in output directly to the browser.
if ("$result" != "" && file_exists ("$fulname"))
{
       print "${result}<br>To retrieve results, right click <a href=\"$webname\">here</a>.  Left click to view in browser.<br>\n";
}
closelog();
?>
</pre>
</body>
</html>
