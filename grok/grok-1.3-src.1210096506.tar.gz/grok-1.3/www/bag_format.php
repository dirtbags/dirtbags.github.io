<?php
$Bag_Fields = array(
0=>"Time", "Duration", "Protocol", "SrcIP", "DstIP",
   "SrcTTL", "SrcPort", "SrcPkts", "SrcBytes", "SrcFlags",
   "SrcEbits", "DstTTL", "DstPort", "DstPkts", "DstBytes",
   "DstFlags", "DstEbits", "reason", "SrcCont", "DstCont",

"J"=>"Time","j"=>"Time",
"T"=>"Julian", "I"=>"Duration", "P"=>"Protocol", "S"=>"SrcIP", "D"=>"DstIP",
"H"=>"SrcTTL", "s"=>"SrcPort", "A"=>"SrcPkts", "B"=>"SrcBytes", "F"=>"SrcFlags",
"E"=>"SrcEbits", "h"=>"DstTTL", "d"=>"DstPort", "a"=>"DstPkts", "b"=>"DstBytes",
"f"=>"DstFlags", "e"=>"DstEbits", "R"=>"reason", "C"=>"SrcCont", "c"=>"DstCont"

);
?>
