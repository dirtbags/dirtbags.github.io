<?php
$SCRIPT="grok_pkts";
$DEBUG = "";
$DEBUG = "debug: $SCRIPT, ";
//if ($DEBUG) error_reporting(E_ALL);

if (file_exists("${SCRIPT}_conf.php")) { include ("${SCRIPT}_conf.php"); } else { include ("grok_conf.php");}
if (file_exists("${SCRIPT}_func.php")) { include ("${SCRIPT}_func.php"); } else { include ("grok_func.php");}
include ("grok_auth.php");

openlog (" $SCRIPT()", LOG_ODELAY, LOG_LOCAL1);

if (validate() > 0) {exit (0);} 

$foo = ImportHTTPVar("foo"); // time,endtime,count,length, ...
if ($DEBUG)  { syslog (LOG_DEBUG, "foo: $foo"); }
if ($foo)
{
  $array = split ("&", $foo);
  foreach ($array as $a)
  {
    if ("$a")
    {
      $varbuf = split ("=", $a);
      $$varbuf[0] = $varbuf[1];
      if ($DEBUG) { syslog(LOG_DEBUG, "$varbuf[0] = $varbuf[1]"); }
    }
  }
}
$exhibit = ImportHTTPVar("exhibit"); // exhibit
$details = ImportHTTPVar("details"); // details
$bpf = ImportHTTPVar("bpf");
$proto = ImportHTTPVar("proto");
$srchost = ImportHTTPVar("src");
$dsthost = ImportHTTPVar("dst");
$dstport = ImportHTTPVar("dport");
$srcport = ImportHTTPVar("sport");
$wfcmod = ImportHTTPVar("wfcmod");
$smacqqmod = ImportHTTPVar("smacqqmod");
$bromod = ImportHTTPVar("bromod");
$sru = ImportHTTPVar("sru");

if ($view != "Packets") {
  print "$SCRIPT, view '$view' is not 'Packets'<br>\n";
  exit (1);
}

$bagcount = "";
$honorcount = "";
if(!$details) {$details = "all";}
if (($details != "all"))
{
  $count = $details;
  $honorcount = "-c $count";
  $bagcount = "-n $count";
};

if ($DEBUG) { syslog(LOG_DEBUG, "exhibit=$exhibit, view=$view"); }
if ($DEBUG) { syslog(LOG_DEBUG, "bpf=$bpf"); }
if ($DEBUG) { syslog(LOG_DEBUG, "time=$time, endtime=$endtime, count=$count, length=$length"); }
if ($DEBUG) { syslog (LOG_DEBUG, "proto=$proto, src=$srchost, dst=$dsthost, sport=$srcport, dport=$dstport"); }
if ($DEBUG) { syslog (LOG_DEBUG, "wfcmod=$wfcmod, smacqqmod=$smacqqmod, bromod=$bromod"); }
if ($DEBUG) { syslog (LOG_DEBUG, "sru=$sru"); }
if ($wfcmod && ($smacqqmod || $bromod)) {
  $earlyout = 1;
} elseif ($smacqqmod && ($wfcmod || $bromod)) {
  $earlyout = 1;
} else if ($bromod && ($$wfcmod || $smacqqmod)) {
  $earlyout = 1;
}
if ($earlyout) {
  print "$SCRIPT, pick only 1 decoder<br>\n";
  exit (1);
}
if ($wfcmod) {
  $details = "all";
  $exhibit = "nosehair";
}
if ( $smacqqmod ) {
  $details = "all";
  $exhibit = "smacqq";
}
if ($bromod) {
  $details = "all";
  $exhibit = "bro";
}

if ($exhibit != "pcap")
{
print "<html><head><title>Packet time: $time</title>\n";
print "<link rel=\"icon\" href=\"images/cpw.jpg\"></head>\n<body>\n<pre>\n";
}

$maxsnips = $RB_NUM_SNIPPITS - 1;
$tcpdswitch = "ttnq";

$BPF = "$VLAN";
$and = ("$BPF") ? " and " : "";
$BPF = ("$proto") ? "proto $proto" : "";
$and = ("$BPF") ? " and " : "";
$BPF = ($srchost) ? "${BPF}${and}src host $srchost" : "$BPF";
$and = ("$BPF") ? " and " : "";
$BPF = ($dsthost) ? "${BPF}${and}dst host $dsthost" : "$BPF";
$and = ("$BPF") ? " and " : "";
$BPF = ($srcport) ? "${BPF}${and}src port $srcport" : "$BPF";
$and = ("$BPF") ? " and " : "";
$BPF = ($dstport) ? "${BPF}${and}dst port $dstport" : "$BPF";
$l=0;
$BPF = trim ($BPF);
if ("$BPF") {$bpf = $BPF;}
if ("$bpf") {$l = strspn ($bpf, "-abcdefghijklmnopqrstuvwxyz.0123456789 []()");}
$bpfname = substr ($bpf, 0, $l);
if ($l > 2) { $bpfname = str_replace (" ", "-", $bpfname); }
else        { $bpfname = "";}
if ($DEBUG) { syslog (LOG_DEBUG,  "BPF=$BPF, bpf=$bpf, bpfname=$bpfname"); }

$filname  = "$time-$endtime";
if ($bpfname) {
  $filname .= "-$bpfname";
} else {
  $filname .= ($proto <= 0) ? "-any" : "-$proto";
  $filname .= ($srchost) ? ",$srchost" : ",any";
  $filname .= ($srcport) ? ":$srcport" : ":any";
  $filname .= ($dsthost) ? ",$dsthost" : ",any";
  $filname .= ($dstport) ? ":$dstport" : ":any";
}
$exh = "$filname.$suffixs[$exhibit]";
$webname = "data/$exh";
$fulname = "$RB_WWW_DIR/$webname";
if ($DEBUG) { syslog (LOG_DEBUG, "webname = $webname, exh = $exh, fulname= $fulname"); }
$slice = "";
$firstpass = "rm -f $fulname; $RB_BIN_DIR/tcpslice $time $endtime 2>/dev/null";
list ($e, $y) = split ("\.", $endtime, 2);
$dur = bcsub("$endtime", "$time" ,6);
if ($DEBUG) { syslog (LOG_DEBUG, "snippit_info list $dur $endtime");}
$fd = popen ("$RB_BIN_DIR/snippit_info list $dur $endtime", "r");
if (!$fd)
{
  exit (1);
} else
{
  $t = 0; $ctime = 0;
  $origcount = $count;
  $FILES = "";
  while (!feof ($fd) && ($count > 0) && ($ctime < $e) && ($line = chop (fgets ($fd, 128))))
  {
    if ($DEBUG) { syslog (LOG_DEBUG, "line: $line, count: $count"); }
    list ($ix, $time) = split (" ", $line);
    $unique = trim ("$time");
    $file = "$RB_PCAP_DIR/$unique.pcap";
    $cmd = "$firstpass $file | $RB_BIN_DIR/tcpdump -w $RB_TMP_DIR/$unique.pcap -r - -s $length $bpf 2>/dev/null";
    if ($DEBUG) { syslog (LOG_DEBUG, "cmd1: $cmd"); }
    $slice = popen ("$cmd", "r");
    while (!feof ($slice) && $slice) { $buf = fgets ($slice, 2048); }
    pclose($slice);
    $FILES = "$FILES $RB_TMP_DIR/$unique.pcap";
    $firstpass = "cat ";
  }
# end of pass to generate pcap stream 
  if ($exhibit == "pcap")
  {
      $cmd = "($RB_BIN_DIR/pcat $FILES) | $RB_BIN_DIR/tcpdump $honorcount -r - -w $fulname -s $length 2>/dev/null; rm -f $FILES";
# extract pcap file from tmp files to www/data directory
      $slice = popen ("$cmd", "r");
      while (!feof ($slice) && $slice) { $buf = fgets ($slice, 2048); }
      pclose($slice);

# send pcapfile to user/application 
      $mm_type="application/cap";
      header("Cache-Control: public, must-revalidate");
      header("Pragma: hack");
      header("Content-Type: " . $mm_type);
      header("Content-Length: " . (string)(filesize($fulname)) );
      header("Content-Disposition: attachment; filename=" . $exh);
      header("Content-Transfer-Encoding: binary\n");
      $fp = fopen ("$fulname", "rb");
      while (!feof($fp) && $fp)
      {
        $buf = fread($fp, 8192);
        print $buf;
      }
      fclose ($fp);
      return;
  }
  if ($exhibit == "pcapfile")
  {
      $cmd = "($RB_BIN_DIR/pcat $FILES) | $RB_BIN_DIR/tcpdump $honorcount -r - -w $fulname -s $length; rm -f $FILES";
      $slice = popen ("$cmd", "r");
      while (!feof ($slice) && $slice) { $buf = fgets ($slice, 2048); }
      pclose($slice);
      $result = grok_file ($fulname, $exh, $exhibit);
  }
  else 
  if ($exhibit == "bag")
  {
      $cmd = "($RB_BIN_DIR/pcat $FILES) | $RB_BIN_DIR/rbag $bagcount -r - -w /dev/null -s $length -Csession,ipaddr=on,dcaptlen=64,scaptlen=64 > $fulname; rm -f $FILES";
      $slice = popen ("$cmd", "r");
      if ($DEBUG) { syslog (LOG_DEBUG, "cmd2: $cmd"); }
      while (!feof ($slice) && $slice) { $buf = fgets ($slice, 2048); }
      pclose($slice);
      $result = grok_file ($fulname, $exh, $exhibit);
  }
  else
  if ($exhibit == "smacqq")
  {
      if ("$sru" == "") { $sru = $smacqqmod; }
      if ("$sru" == "") {
        $cmd = "nroff /usr/local/src/smacq/doc/smacq.1 > ${fulname}";
      } else {
        $available = file_get_contents ("smaqmods");
	$cmd = "(source $RB_README; grep '$sru:' $RB_WWW_DIR/smaqmods | sed -e 's/^$sru://')";
        if ($DEBUG) { syslog (LOG_DEBUG, "cmd3a: $cmd"); }
        $slice = popen ("$cmd", "r");
	$sru = "";
	while (!feof ($slice) && $slice && !$sru) { $sru = fgets ($slice, 2048); } 
        pclose($slice);
        $cmd = "(source $RB_README; $RB_BIN_DIR/pcat $FILES | tcpdump $honorcount -r - -s 1518 -w - | $RB_BIN_DIR/smacqq \"$sru\") > $fulname ; rm -f $FILES";
      }
      if ($DEBUG) { syslog (LOG_DEBUG, "cmd3b: $cmd"); }
      $slice = popen ("$cmd", "r");
      while (!feof ($slice) && $slice) { $buf = fgets ($slice, 2048); }
      pclose($slice);
      $result = grok_file ($fulname, "$exh", $exhibit);
  }
  else 
  if ($exhibit == "nosehair")
  {
      if ( "$sru" == "") { $sru = $wfcmod; }
      if ( "$sru" == "") {
        $cmd = "(cat /usr/local/src/nosehair/SPELLBOOK) > ${fulname}";
      } else {
        $cmd = "($RB_BIN_DIR/pcat $FILES) | NOSEHAIR_LIB=/usr/share/nosehair/lib $RB_BIN_DIR/wfc -r - $bpf \"$sru\" >& ${fulname}; rm -f $FILES";
      }
      $slice = popen ("$cmd", "r");
      if ($DEBUG) { syslog (LOG_DEBUG, "cmd4: $cmd"); }
      while (!feof ($slice) && $slice) { $buf = fgets ($slice, 2048); }
      pclose($slice);
      $result = grok_file ($fulname, $exh, $exhibit);
  }
  else 
  if ($exhibit == "tcpdump")
  {
      $cmd = "($RB_BIN_DIR/pcat $FILES) | $RB_BIN_DIR/tcpdump -ttttneAr - -s $length $honorcount > $fulname; rm -f $FILES";
      if ($DEBUG) { syslog (LOG_DEBUG, "cmd5: $cmd"); }
      $slice = popen ("$cmd", "r");
      while (!feof ($slice) && $slice) { $buf = fgets ($slice, 2048); }
      pclose($slice);
      $result = grok_file ($fulname, $exh, $exhibit);
  }
  else 
  if ($exhibit == "snort")
  {
      if ($sru) {
        $z = getenv ('LA_employeeNumber');
        $rules="$RB_TMP_DIR/snort.rule";
        $sruFile = fopen ("$rules", "w");
        $noslashes = stripslashes ($sru);
        fputs ($sruFile, $noslashes);
        fclose ($sruFile);
        $config = "$RB_SNORT_DIR/tsnort.conf";
      }
      else
      {
        $config = "/etc/snort/snort.conf";
      }
       $cmd = "source $RB_README; cd $RB_BASE_DIR; export config=$config; ($RB_BIN_DIR/pcat $FILES) | $RB_BIN_DIR/runsnort >& $fulname; rm -f $FILES /tmp/alert"; 
      if ($DEBUG) { syslog (LOG_DEBUG, "cmd6: $cmd"); }
      $slice = popen ("$cmd", "r");
      while (!feof ($slice) && $slice) { $buf = fgets ($slice, 2048); }
      pclose($slice);
      $result = grok_file ($fulname, "$exh", $exhibit);
  }
  else
  if ($exhibit == "bro") {
      if ( "$bromod" != "") { $sru = "/usr/local/bro/policy/${bromod}.bro"; }
      if ( "$sru" == "")
      {
	$cmd = "cat /usr/local/src/bro/doc/user-manual/Bro-user-manual.pdf > $fulname";
      } else {
        $cmd = "source $RB_README;($RB_BIN_DIR/pcat $FILES) | (cd $BROHOME/logs;BROPATH=/usr/local/bro/policy $RB_BIN_DIR/bro -r - $sru 2>&1) > $fulname;  rm -f $FILES";
      }
      if ($DEBUG) { syslog (LOG_DEBUG, "cmd7: $cmd"); }
      $slice = popen ("$cmd", "r");
      while (!feof ($slice) && $slice) { $buf = fgets ($slice, 2048); }
      pclose($slice);
      $result = grok_file ($fulname, "$exh", $exhibit);
  }
  else
  if ($exhibit == "decodeip") {
      $cmd = "(source $RB_README; $RB_BIN_DIR/pcat $FILES |\
        $RB_BIN_DIR/tcpdump -xttqn -s$length $honorcount -r - | $RB_BIN_DIR/DecodeIP -Xl$length) > $fulname; rm -f $FILES";
      $slice = popen ("$cmd", "r");
      while (!feof ($slice) && $slice) { $buf = fgets ($slice, 2048); }
      pclose($slice);
      $result = grok_file ($fulname, "$exh", $exhibit);
  }
  else {
      print "grok_pkts.php is only partially implimented, try with snort.<br>";
  }
  if ("$result" != "" && file_exists ("$fulname"))
  {
      chmod("${fulname}", 0644);
      print "${result}<br>To retrieve it, right click <a href=\"$webname\">here</a>.<br>";
  } else {
      print "Failed to create $webname. Haven't a clue.  Maybe there was no data for<br>";
      print "the time period specified.<br>";
  }
}
?>
</pre>
</body>
</html>
