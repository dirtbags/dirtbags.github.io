<?php
function grok_time ($value)
{
        $totime = strtotime ($value);
	if ($totime > 0) {
	  print "debug TIME: value=$value, totime=$totime<br>\n"; 
	  $value = $totime;
	}
        $stuff = split (" [ ]*", $value, 7);
        $nstuff = count ($stuff);
        $x = strspn($value, "abcdefghijklmnopqrstuvwxyz");
	$y = strlen($value);
	if ($x == $y)
	{
	  $nstuff = 0;
	}
	$i = 0;
	print "debug TIME: nstuff = $nstuff, value is $value, totime is $totime<br>\n";
	while ( $i < $nstuff) {print ", $i: $stuff[$i]"; $i++;}
	print "<br>end debug:<br>\n"; 
        if ($y == 28) {$nstuff = 1;}
        switch ($nstuff) {
	case 0:
	  if (!strcmp ($value, "now"))
	    { $julian = $now; }
	  else {
	    if (!strcmp ($value, "oldest"))
	      { $julian = $oldest_time[0]; }
	    else
	      { $julian = 0; }
	  }
	  break;

        case 1: // just time entered OK
          $l = strlen ($value);
          switch ($l) {
          case 32: // totally unambiguous, but useless time

                preg_match ("/^([0-9][0-9][0-9][0-9])-([0-9][0-9])-([0-9][0-9])T([0-9][0-9]):([0-9][0-9]):([0-9][0-9])\.[0-9]*-([09][09]):([09][09])/i", $value, $m);
		print "debug: $m[1], $m[2], $m[3], $m[4], $m[5], $m[6], $m[7], $m[8]<br>\n";

	  	break;
          case 10: //`date '+%s'`
  	    $julian = $value;
  	    break;
          case 21: //snort alert fmt: 02/03-15:49:56.300878
            preg_match ("/^([0-9][0-9])\/([0-9][0-9])-([0-9][0-9]):([0-9][0-9]):([0-9][0-9])\.[0-9]*/i", $value, $m);
            $julian = mktime (1*$m[3], 1*$m[4], 1*$m[5], 1*$m[1], 1*$m[2],
	                      $current_time["year"]);
            break;
          case 28: //web log fmt: [28/May/2005:15:10:22 -0600]
            preg_match ("/^\[([0-9][0-9])\/([a-z]*)\/([0-9][0-9][0-9][0-9]):([0-9][0-9]):([0-9][0-9]):([0-9][0-9]) -.*/", $value, $m);
           $mon = $m[2];
//print "debug: $m[4],$m[5],$m[6],$mon,$m[1],$m[3]<br>\n";
            $julian = mktime (1*$m[4], 1*$m[5], 1*$m[6], $month[$mon], 1*$m[1], $m[3]);
            break;
          default:
      	    {
              $value = check_equal ("Time", ":0123456789", $value);
              $hms = split (":", $value, 3);
              $hms[0] *=1;
              $hms[1] *=1;
              $hms[2] *=1;
              // maintain some sanity
              if ($hms[0] > $current_time["hours"])
	      {
                // must be the previous day
                $current_time = getdate($now - 86400);
              }
              // if minutes are beyond then just set to current and go
              if ($hms[1] > $current_time["minutes"])
              {
                $hms[1] = 1*$current_time["minutes"];
                $hms[2] = 0;
              }
              $julian = mktime ($hms[0], $hms[1], $hms[2], $current_time["mon"],
	                $current_time["mday"], $current_time["year"]);
            }
	    //print "debug: default, value=$value, julian = $julian<br>";
  	    break;
          }
//	  print "debug: value=$value, julian = $julian<br>";

          break;
        case 2: // month/day/year (or year/month/day) hours:minutes:seconds
          $value = check_equal ("Time", ":0123456789", $stuff[1]);
  	  $hms = split (":", $value, 3);
          $dat = split ("[-/.]", "$stuff[0]", 3);
            
          if ($dat[0] > 2000)
          {
            $y = $dat[0];
            $dat[0] = $dat[1];
            $dat[1] = $dat[2];
            $dat[2] = $y;
          } 
          if (!$dat[1]) {$dat[1] = $current_time["mday"];}
          if (!$dat[2]) {$dat[2] = $current_time["year"];}
          if (($dat[2] > 0) && ($dat[2] < 30)) { $dat[2] += 2000; }
        //print "debug: mktime(1*$hms[0], 1*$hms[1], 1*$hms[2], 1*$dat[0],1*$dat[1],$dat[2]<br>";
          $julian = mktime(1*$hms[0], 1*$hms[1], 1*$hms[2], 1*$dat[0],1*$dat[1],
	                   $dat[2]);
          break;
        case 3: // mon day time 
          $stuff[1] = $stuff[1]*1;
          $value = check_equal ("Time", ":0123456789", $stuff[2]);
          $hms = split (":", $value, 3);
          $julian = mktime(1*$hms[0], 1*$hms[1], 1*$hms[2], $month[$stuff[0]],
	                   $stuff[1], $current_time["year"]);
          break;
        case 4: // day mon year time
          $value = check_equal ("Time", ":0123456789", $stuff[3]);
          $hms = split (":", $value, 3);
          $value = $stuff[0] * 1;
        //print "debug: mktime(1*$hms[0], 1*$hms[1], 1*$hms[2], $stuff[0], $stuff[1], $stuff[2]<br>";
          if ($value > 2000) {
            $julian = mktime(1*$hms[0], 1*$hms[1], 1*$hms[2], $stuff[1],
			   $stuff[2], $value);
          } else {
            $julian = mktime(1*$hms[0], 1*$hms[1], 1*$hms[2], $value,
			   $stuff[1], $stuff[2]);
          }   
          break;
        case 6: // linux `date` OK or mail date
          $value = check_equal ("Time", ":0123456789", $stuff[3]);
	  $hms = split (":", $value, 3);
          if ($hms > 2000) {
            $value = check_equal ("Time", ":0123456789", $stuff[4]);
	    $hms = split (":", $value, 3);
	    $julian = mktime(1*$hms[0], 1*$hms[1], 1*$hms[2], 1*$month[$stuff[2]], 1*$stuff[1], $stuff[3]);
          } else {
	    $julian = mktime(1*$hms[0], 1*$hms[1], 1*$hms[2], 1*$month[$stuff[1]], 1*$stuff[2], $stuff[5]);
          }
          
          break;
        default: // parse error gives you the current
          print "Please send me this time value:<br";
          print "<b>$value</b>.<br>";
          print "Maybe I can add a parse for it. For now I'll use the current time.<br>";
  	  $julian = $now;
        break;
        }
	//print "debug: julian is $julian<br>";
        if ($julian != 0)
	{
          $value = $julian;
        }
        else
	{
          printf ("Using current time, error parsing date/time %s<br>\n",
	          $value);
  	  $value = $now;
        }
	if ($value < $oldest_time[0]) {$value = $oldest_time[0];}
        if (("$Packets_Button_x" == "")) {
  	  $starttime = $value;
  	} 
	//print "debug: I'm done value is $value, starttime is $starttime<br>";

	return "$value";
}
?>
