<?php
$ME="grok";
$SCRIPT_NAME="$ME.php";
  if (file_exists("${ME}_conf.php")) { include ("${ME}_conf.php"); } else { include ("grok_conf.php");}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<!--                            grok_info.php -->
<head>
<script language="JavaScript">
<!--
-->
</script>
<link type="text/css" rel="stylesheet" href="grok_style.css">
<link rel="icon" href="images/cpw.jpg">
<title>GROK</title>
</head>
<body>
<tt>
<?php
  $version = ("$ME" == "grok") ? "Version $GROK_VERSION"
                               : "Test Version $GROK_VERSION";

  printf ("<STRONG>GROK, %s</STRONG> <A HREF=\"mailto:cpw@lanl.gov?subject=GROK %s\">Mail</a> comments or suggestions regarding <a href=\"help/grok_def.html\">grok</a>.", $version, $GROK_VERSION);
  $truncate=popen ("grep truncate $RB_ETC_DIR/grok/sess.conf | sed -e 's/^.*=//'", "r");
  $tmp = fgets ($truncate, 32);
  pclose ($truncate);
  $also = "Bag ";
  if ("$tmp" != "") {
    printf (" <font color=red>Warning</font>, bag is configured to truncate pcap files to just include protocol headers. This mode of operation is contrary to the grok philosophy that more information is better than less information.");
    $also = "In addition, it";
  }
  $first = popen ("grep first $RB_ETC_DIR/grok/sess.conf | sed -e 's/^.*=//'","r");
  $tmp = fgets ($first, 32);
  pclose ($first);
  if ("$tmp" != "") {
      printf ("  %s is recording all data in the first data packet, which can lead to some long or extremely short session records depending on the service being provided.", $also);
  }
  if (file_exists("${ME}_instructions.php")) { include ("${ME}_instructions.php"); } else { include ("grok_instructions.php");}
?>
</body>
</html>
