<?php
$SCRIPT_NAME="cpw.php";

include ("grok_conf.php");
include ("grok_func.php");
include ("grok_hextable.php");

?>
<HTML>
<head><title>cpw.php</title></head>
<body>
<?php
print "The RB_DATA_DIR is $RB_DATA_DIR<br>\n";
$i=3;
if ($pkt_fields[$i])
{
  $entity = $pkt_fields[$i];
  print "case $entity<br>\n";
  print "reverse $pkt_fields[$entity]<br>\n";
} else {
  print "nada<br>\n";
}
?>
</body>
</HTML>
