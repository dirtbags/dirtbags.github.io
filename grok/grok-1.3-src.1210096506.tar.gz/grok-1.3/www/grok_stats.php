<?php

$SCRIPT="grok_stats";
$DEBUG = "debug: $SCRIPT, ";
$DEBUG = "";
//if ($DEBUG) error_reporting(E_ALL);

if (file_exists("${SCRIPT}_conf.php")) { include ("${SCRIPT}_conf.php"); } else { include ("grok_conf.php");}
if (file_exists("${SCRIPT}_func.php")) { include ("${SCRIPT}_func.php"); } else { include ("grok_func.php");}
include ("grok_auth.php");
    if (file_exists("geoipcity.inc")) {
      include ("geoipcity.inc");
      $gi = geoip_open("/usr/local/share/GeoIP/GeoIPCity.dat", GEOIP_STANDARD);
    }
global $HTTP_COOKIE_VARS;

openlog ("$SCRIPT()", LOG_ODELAY, LOG_LOCAL1);
if (validate() > 0) {exit (0);} 

$column = array ("Freq"=>"0", "Duration"=>6, "Pkts Sent"=>"7", "Bytes Sent"=>"8", "Pkts Recvd"=>"9", "Bytes Recvd"=>"10");
$top = "$RB_SENSOR_HOST Top ";

include ("gettimes.php");

// modifiers to sort from table 1
$exhibit = ImportHTTPVar("exhibit");
if (!$exhibit) { $exhibit = "decode"; }
$x = ImportHTTPVar("snet");
$snet = (strlen ($x) == strspn ($x, "0123456789.")) ? $x : "BAD";
$x = ImportHTTPVar("dnet");
$dnet = (strlen ($x) == strspn ($x, "0123456789.")) ? $x : "BAD";
$x = ImportHTTPVar("port");           //which col to sort on
$port = (strlen ($x) == strspn ($x, "0123456789")) ? $x : "BAD";
// modifiers to sort from table 2
$x = ImportHTTPVar("snip");         // UTC seconds for 5 minute snippit
if (!$x) {$x = $almost;}
$snippit = (strlen ($x) == strspn ("$x", " -ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz:0123456789\./")) ? $x : "BAD";
if ($DEBUG) syslog (LOG_DEBUG, "$DEBUG snip is $x, snippit is $snippit");
$y = $snippit * 1;
if ("$y" != "$x") {$snippit = grok_time ("$snippit");}
if ($DEBUG) syslog (LOG_DEBUG, "snippit is $snippit");
$snippit = $snippit * 1;
$x = ImportHTTPVar("col");           //which col to sort on
if ("$x" == "")
  $col = 0;
else 
  $col = (strlen ($x) ==  strspn ($x, "0123456789")) ? $x : "BAD";
$x = ImportHTTPVar("ttl");           //which col to sort on
$ttl = (strlen ($x) == strspn ($x, "0123456789")) ? $x : "BAD";
$ttl = ("$ttl" == "0") ? $ttl = "&nbsp;" : $ttl;
$x = ImportHTTPVar("head");         //text for Top n
$head = (strlen ($x) == strspn ($x, "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz,. ")) ? $x : "BAD";
$x = ImportHTTPVar("todo");
$todo = (strlen ($x) == strspn ($x, "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz ")) ? $x : "Freq";

$foobahs = "";
if ($head)  {$foobahs = "$head ";}
$N = 100;
$limit = "| head -$N";

if ($snippit > 0) {
  $handle = popen ("$RB_BIN_DIR/snippit_info $snippit 1", "r");
  $snippit = chop (fread ($handle, 2048));
  preg_match ("/ ([0-9\.]*)/", $snippit, $matches);
  $snippit = $matches[1];
  if ($DEBUG) syslog (LOG_DEBUG, "snippit is $snippit");
  pclose ($handle);
}

if ("$todo") { $col = $column[$todo]; }
$savcol = $col;
if ("$col") {$col = "+${col}rn"; } else { $col = '+0rn'; }
$PROG = "$RB_BIN_DIR/snippit_info $snippit 1";
$handle = popen ("$PROG", "r");
$line = chop (fread ($handle, 2048));
pclose ($handle);
$result = split (' ', $line);
$sniptime = $result[1];
if ($DEBUG) syslog (LOG_DEBUG, "snippit is $sniptime");
$PROG = "$RB_BIN_DIR/pdaydir $sniptime";
$handle = popen ("$PROG", "r");
$database = chop (fread ($handle, 2048));
pclose ($handle);
$result = split ("\.", $sniptime);
$tstart = date ("M d H:i", $result[0]);
$date = $result[0];
$backoff = 2 * ($RB_CAP_MINUTES * 60);

if ($DEBUG) syslog (LOG_DEBUG, "date $result[0] is $tstart");

print "<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional\">\n";
print "<html>\n<head>\n";
print "<title>$top</title>\n";
print "<link rel=\"icon\" href=\"images/cpw.jpg\">\n";
print "<link rel=\"stylesheet\" type=\"text/css\" charset=\"utf-8\" media=\"screen\" href=\"stats.css\">\n";
print "</head><body>\n";
print "<center>\n";
print "<form target=\"$top\" action=\"grok_stats.php\" method=\"post\">\n";
// print "   <input type=\"reset\"  name=\"reset\" value=\"Reset\"td>\n";
//print "   <input type=\"hidden\" name=\"snip\"  value=\"$snippit\">\n";
print "   <input type=\"hidden\" name=\"head\"  value=\"$head\">\n";
print "   <input type=\"hidden\" name=\"col\"   value=\"$savcol\">\n";
print "   <table border=\"0\" cellspacing=\"0\" summary=\"Collect optional source ip, dst ip or port\">\n";
print "      Src IP <input size=\"13\" type=\"text\" value=\"$snet\" name=\"snet\">\n";
print "      Dst IP <input size=\"13\" type=\"text\" value=\"$dnet\" name=\"dnet\">\n";
print "      Port <input size=\"5\" type=\"text\" value=\"$port\" name=\"port\">\n";
print "      TTL <input size=\"5\" type=\"text\" value=\"$ttl\" name=\"ttl\">\n";
print "      SNIP <input size=\"17\" type=\"text\" value=\"$snippit\" name=\"snip\">\n";
print "      Decode <select size=\"1\" name=\"exhibit\">\n";
      $sp = "      ";
      foreach ($dcodes as $value)
      if ($value == $exhibit) print "$sp<option selected>$value</option>\n";
      else print "$sp<option>$value</option>\n";
print "$sp</select>\n";
print "$tstart<br>";
print "    </table>";
$awk = "awk";
$pre = "'";
$filter = "";
if ("$snet") {
  $filter = "$filter$awk $pre $2 ~/^$snet/"; $pre = "&&"; $awk = "";
}
if ("$dnet") {
  $filter = "$filter$awk $pre $3 ~/^$dnet/"; $pre = "&&"; $awk = "";
}
if ("x$port" != "x") { $limit=""; $top = "$RB_SENSOR_HOST ";
  $filter = "$filter$awk $pre $5 ~/^$port$/";$pre = "&&"; $awk = "";
}
if ("x$ttl" != "x") {
  $filter = "$filter$awk $pre $6 ~/^$ttl$/"; $pre = "&&"; $awk = "";
}
if ("$filter" != "") {
  $filter = "$filter' |";
}

$cmd = "(cat $RB_ARCH_DIR/$database/$sniptime.$RB_ARKFIELDS | $filter sort 2>/dev/null ${col} $limit > /tmp/$RB_ARKFIELDS;wc -l /tmp/$RB_ARKFIELDS)";
if ($DEBUG) syslog (LOG_DEBUG, "cmd: $cmd");
$slice = popen ("$cmd", "r");
$N = explode (" ", chop (fgets ($slice, 255)));
pclose ($slice);
$title = "${top}$N[0]";
$sp = "  ";
print "$sp<h4>$title ${foobahs} sorted by $stat_cols[$savcol]</h4>\n";
$cmd = "(cat /tmp/$RB_ARKFIELDS)";
$slice = popen ("$cmd", "r");
?>
  <table summary="Display summary utilization by ip pair" cellspacing="2" id="stats">
    <thead class="toprow">
<?
    print "$sp$sp<tr><td><input type='submit' name='todo' value='Freq'></td><td></td><td>Src IP</td><td>C</td><td>Dst IP</td><td>C</td><td>Proto</td><td>Port</td><td>TTL</td><td><input type='submit' name='todo' value='Duration'></td><td><input type='submit' name='todo' value='Pkts Sent'></td><td><input type='submit' name='todo' value='Bytes Sent'></td><td><input type='submit' name='todo' value='Pkts Recvd'></td><td><input type='submit' name='todo' value='Bytes Recvd'></td></tr>\n";
?>
    </thead>
<?
$i = 0;
while (!feof($slice) && $slice)
{
   $data = ($i&1) ? "'data1'" : "'data0'";
   $line = chop (fgets ($slice, 255));
   if ("$line") { 
   $result = split (' ', $line);
   $pktcnt = $result[7] + $result[9];
   $d = $date - ($result[5] + $backoff);
   if ("$result[0]") {
     if (!$result[5]) { $result[5] = "&nbsp;"; }

     if (file_exists("geoipcity.inc")) {
          $sgc = geoip_country_code_by_addr ($gi, $result[1]);
          $dgc = geoip_country_code_by_addr ($gi, $result[2]);
     } else {
          $sgc = "";
          $dgc = "";
     }
     print "$sp$sp<tr>";
     print "<td class=$data>$result[0]</td>";
     print "<td class=$data><a target=\"_blank\" href=\"https://$RB_CSIRT/$HOST/grok_sess.php?exhibit=$exhibit&details=all&tpkts=$pktcnt&endtime=$date&time=$d&length=1518&src=$result[1]&dst=$result[2]&proto=$result[3]&dport=$result[4]&view=Sessions\">&laquo;</a></td>";
     print "<td class=$data><a target=\"_blank\" href=\"https://$RB_CSIRT/hostlookup/?$result[1]\">$result[1]</a></td>";
     print "<td class=$data>$sgc</td>";
     print "<td class=$data><a target=\"_blank\" href=\"https://$RB_CSIRT/hostlookup/?$result[2]\">$result[2]</a></td>";
     print "<td class=$data>$dgc</td>";
     print "<td class=$data>$result[3]</td>";
     print "<td class=$data>$result[4]</td><td class=$data>$result[5]</td>";
     print "<td class=$data>$result[6]</td><td class=$data>$result[7]</td>";
     print "<td class=$data>$result[8]</td><td class=$data>$result[9]</td>";
     print "<td class=$data>$result[10]</td>";
     print "</tr>\n";
   }
   $i++;
   }
}
?>
  </table>
  </form>
  </center>
<?
pclose($slice);
flush();
#unlink("/tmp/$RB_ARKFIELDS");
?>
</body>
</html>
