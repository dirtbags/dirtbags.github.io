#!/usr/bin/perl

# expects:    
# 3 12 15 170 2 160.81.65.49 1 3 247 5.06 
# Y M  D  snp n S            P s F   T
# 1 2  3  4   5 6            7 8 9   10

# generates daily summaries for nSPdFt data
# nSPdFt was changed 2004/09/22 to nSDPdFt data 

$ix = "";
while (<>) {
  chomp;
  ($y,$m,$d,$snip,$n,$S,$P,$s,$ttl,$t) = split();
  $nix = "$m-$d";
  if ( "$ix" && ("$nix" ne "$ix"))
  {
    $i=0;@sortme = ();
    foreach $key (keys %time) { $sortme[$i++] = $key; }
    $newline = '';
    foreach $key (reverse sort timefreq @sortme) {
      printf "%s %d %d \n", $key, $time{$key}, $sess{$key};
      $newline = "\n";
    }
    %time = ();
    %sess = ();
  }
  $time{"$m $d $S $P $s"} += $t;
  $sess{"$m $d $S $P $s"} += $n;
  $ix = "$nix";
}
{
  $i=0;@sortme = ();
  foreach $key (keys %time) { $sortme[$i++] = $key; }
  $newline = '';
  foreach $key (reverse sort timefreq @sortme) {
    printf "%s %d %d\n", $key, $time{$key}, $sess{$key};
    $newline = "\n";
  }
}

exit 0;
sub timefreq {
  $time{$a} <=> $time{$b};
}
sub sessfreq {
  $sess{$a} <=> $sess{$b};
}
