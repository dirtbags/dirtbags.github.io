<?php
$ME="grok_incident";
$SCRIPT_NAME="$ME.php";
include "incident.html";
