<?php
if (file_exists("${ME}_conf.php")) { include ("${ME}_conf.php"); } else { include ("grok_conf.php");}
if (file_exists("${ME}_func.php")) { include ("${ME}_func.php"); } else { include ("grok_func.php");}

$time = ImportHTTPVar("time");
$data = ImportHTTPVar("data");
print "<html><head><title>UNHEX $time</title>\n";
print "<link rel=\"icon\" href=\"images/cpw.jpg\"></head>\n<body>\n<pre>\n";

  $foo = localtime ($time, 1);
  printf ("Time:%d:%d:%d<br>\n",
		$foo["tm_hour"],
		$foo["tm_min"],
		$foo["tm_sec"]
		);
  $cmd ="echo $data | $RB_BIN_DIR/hextotex | tr '<>' '{}'";
  $line = popen ("$cmd", "r"); 
  while (!feof ($line) && "$line")
  {
	$tmp = fgets ($line, 2048);
	$tmp = substr ($tmp, 0, (strlen($tmp) - 1));
	print "$tmp<br>";
  }
?>

</pre>
</body>
</html>
