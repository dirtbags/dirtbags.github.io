#!/bin/sh

# generate pattern that will match a domains routers ethernet addresses
# usage pat=`setpat`

function setpat ()
{
 # set -x
  pattern="";
  bar="";
  if test -z "$RB_ETC_DIR"; then
    cat <<EOF
  Error in function 'setpat', your RB environment is not set yet?
  Better put on your thinking cap.  I haven't a clue.
EOF
    #shopt -u -o xtrace
    exit 1
  else 
    L="$RB_ETC_DIR/grok/LINKADDRS"
    if test ! -f $L; then
      cat > $L <<EOF
# Routers or other devices on the network you are sniffing and the last
# two bytes of their ethernet address (in hex).  The empty line below
# is required.  This file created by grok_func.sh you should probably
# modify it.

EOF
      set `/sbin/ifconfig | grep Ethernet | head -1 | sed -e 's/^.* ..:..:..:..://' | tr -d ':'`
      export RB_DOMAIN=`hostname`
      HWaddr=$1
      echo $RB_DOMAIN $HWaddr >> $L
    else
      cat $RB_ETC_DIR/grok/LINKADDRS | sed -n -e '/^[a-zA-Z]/p' | while read r m; do
        if test "$r" = "$RB_DOMAIN"; then
        echo -n "${pattern}${bar}$m"
        bar="|"
      fi
      done
    fi
  fi
  #shopt -u -o xtrace
}
