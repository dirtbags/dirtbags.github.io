<?php
include ("rb_include.php")
?>
<!--				grok_stat-table.php
-->
<table frame="box" rules="groups" border="2" cellspacing="0"
summary="This table shows libpcap and device statistics for the selected period.">
<caption style="font-size: 10pt; color: chocolate;"><strong>Bag Statistics Records</strong></caption>
<thead valign="top">
<tr style="font-size: 10pt; color: chocolate;">
      <th colspan="2">Time
      <th colspan="4">Bagged packets
      <th colspan="2">
<?php
$RB_VOID
?>
      <th colspan="5">MMAP libpcap statistics
<colgroup align="center">
<colgroup align="center">
<colgroup align="right">
<colgroup align="right">
<colgroup align="right">
<colgroup align="right">
<colgroup align="right">
<colgroup align="right">
<colgroup align="right">
<colgroup align="right">
<colgroup align="right">
<colgroup align="right">
<colgroup align="right">

<tr style="font-size: 8pt; color: chocolate;">
    <th>start
    <th>elapsed
    <th>processed
    <th>dropped
    <th>total
    <th>bytes
    <th>packets
    <th>bytes
    <th>index
    <th>consec
    <th>polls  
    <!--
    <th>ignored
    <th>specious
    -->
</thead>
