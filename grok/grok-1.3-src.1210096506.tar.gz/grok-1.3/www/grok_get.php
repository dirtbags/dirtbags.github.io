<?php
$_POST = $_GET;
include ("grok.php");
?>

