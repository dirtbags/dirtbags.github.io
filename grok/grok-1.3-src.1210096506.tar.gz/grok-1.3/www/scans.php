<?php
$ME="scans";
$DEBUG = "debug: $ME, ";
$DEBUG = "";
if ($DEBUG) error_reporting(E_ALL);

$SCRIPT_NAME="$ME.php";

if ( $DEBUG) { syslog (LOG_DEBUG, "$DEBUG");}
#include ("grok_auth.php");
#if (file_exists("${ME}_func.php")) { include ("${ME}_func.php"); } else { include ("grok_func.php");}

// loop to wait for things to settle
openlog ("      $ME()", LOG_ODELAY, LOG_LOCAL1);
#if (validate() > 0) {exit (0);}

if (file_exists("${ME}_refresh.php")) { include ("${ME}_refresh.php"); } else { include ("grok_refresh.php");} 
?>
</head>
<body>
<center><img src="cgi-bin/world1.py"></center>
</body>
</html>
