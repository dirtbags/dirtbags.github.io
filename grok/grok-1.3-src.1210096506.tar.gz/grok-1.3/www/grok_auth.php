<?php
function get_login_userID($requester) {
    global $HTTP_COOKIE_VARS;

    # SessionID is the session cookie name
    $session = $HTTP_COOKIE_VARS['SessionID'];
    # REMOTE_ADDR is the browser IP address
    $browser = $requester;

    if ($session == "") {
        return 0;
    }
    $result = _wwwauth_sock("check~$browser~$session");
    $vals = explode("~", $result);
    if ($vals[0] != 0) {
        return 0;
    }
    //{ syslog (LOG_DEBUG, "get_login_userID \"$vals[2]\""); }
    return "$vals[2]";
}
#   Open socket to wwwauth, send request, read reply

function _wwwauth_sock($request) {

    global $WWWAUTH_SERVER;
    global $WWWAUTH_PORT;

    # open socket, 5 second timeout to make connection
    $fp = fsockopen($WWWAUTH_SERVER, $WWWAUTH_PORT, $errnum, $errstr, 5 );
    if (! $fp) {
        return "500: wwwauth service is not available, try later";
    }
    # set 5 second timeout for reads
    socket_set_timeout($fp, 5, 0);
    fputs($fp, $request);
    $reply = fgets($fp, 1024);
    # check reply, line could be empty, time out, etc.
    fclose($fp);
    if ($reply == "") {
        return "500: wwwauth service is not available, try later";
    }
    return "$reply";
}
?>
